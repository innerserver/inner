const state = {
  user: null,
  settings: { serverEnabled: true, roomName: "Inner" },
  rooms: [],
  selectedRoomId: "main",
  messages: [],
  pendingSends: [],
  replyToMessage: null,
  dms: [],
  pendingDms: [],
  replyToDm: null,
  dmGroups: [],
  people: [],
  selectedDmUser: "",
  adminDmFilter: "all",
  accountSearch: "",
  logSearch: "",
  logDate: "",
  files: [],
  accountRequests: [],
  uploadQueue: [],
  vpn: {},
  locations: [],
  users: [],
  backups: [],
  profiles: {},
  friends: { friends: [], incoming: [], outgoing: [] },
  invites: [],
  reports: [],
  readReceipts: {},
  moderationLogs: [],
  logs: [],
  dev: null,
  presence: [],
  voiceRooms: [],
  voiceRoomId: "lobby",
  voiceStream: null,
  voicePeers: [],
  voiceConnections: new Map(),
  voicePendingCandidates: new Map(),
  voiceMuted: false,
  voiceDeafened: false,
  voiceVideoEnabled: false,
  voiceCameraOff: true,
  incomingCall: null,
  ringtoneContext: null,
  ringtoneTimer: null,
  bots: [],
  plugins: [],
  automod: {},
  store: { items: [], orders: [] },
  aiRequests: [],
  aiConfigured: false,
  ws: null,
  reconnectTimer: null,
  wsPingTimer: null,
  wsOutbox: [],
  wsEverConnected: false,
  restoredScrollKeys: new Set(),
  clientId: "",
  peers: new Map(),
  peerLocations: new Map(),
  peerConnections: new Map(),
  pendingCandidates: new Map(),
  localStream: null,
  screenRoomId: "",
  remoteScreenRoomId: "",
  remoteScreenStream: null,
  remoteFrom: "",
  activeView: "messages",
  loggedIn: false,
  installPrompt: null,
  notificationsEnabled: false,
  inviteAutoJoined: false,
};

window.state = state;

let rtcConfig = {
  iceServers: [
    { urls: "stun:stun.l.google.com:19302" },
    { urls: "stun:stun1.l.google.com:19302" },
    { urls: "stun:global.stun.twilio.com:3478" },
  ],
  iceCandidatePoolSize: 4,
};

const viewRoutes = {
  dashboard: "/dashboard",
  messages: "/",
  dms: "/dms",
  friends: "/friends",
  profile: "/profile",
  store: "/store",
  files: "/files",
  voice: "/voice",
  screen: "/screen",
  admin: "/admin",
  hmd: "/hmd",
};

const els = {};

document.addEventListener("DOMContentLoaded", () => {
  state.notificationsEnabled = getStoredFlag("innerNotifications");
  restoreUiState();
  cacheElements();
  bindEvents();
  loadState().catch((error) => showLogin(error.status === 401 ? "" : error.message));
});

function cacheElements() {
  [
    "loginView",
    "appView",
    "loginForm",
    "loginUsername",
    "loginPassword",
    "loginError",
    "accountRequestForm",
    "requestUsername",
    "requestDisplayName",
    "requestContact",
    "requestNote",
    "submitAccountRequestButton",
    "accountRequestStatus",
    "logoutButton",
    "roomName",
    "serverPill",
    "currentUser",
    "connectionStatus",
    "messageCount",
    "fileCount",
    "peerCount",
    "installButton",
    "notificationsButton",
    "siteNotice",
    "dashboardView",
    "dashboardState",
    "dashboardGrid",
    "presenceList",
    "mentionList",
    "messagesView",
    "dmsView",
    "friendsView",
    "profileView",
    "storeView",
    "filesView",
    "voiceView",
    "screenView",
    "adminView",
    "hmdView",
    "adminNavButton",
    "hmdNavButton",
    "messageState",
    "roomSelect",
    "inviteJoinForm",
    "inviteCodeInput",
    "joinInviteButton",
    "messageList",
    "messageJumpBottomButton",
    "messageForm",
    "messageInput",
    "messageAttachment",
    "messageSelfieInput",
    "messageSelfieButton",
    "sendMessageButton",
    "dmState",
    "dmPeerSelect",
    "dmGroupForm",
    "dmGroupName",
    "dmGroupMembers",
    "createDmGroupButton",
    "deleteDmGroupButton",
    "dmCallPanel",
    "dmCallState",
    "dmVoiceCallButton",
    "dmVideoCallButton",
    "dmShareScreenButton",
    "dmStopScreenButton",
    "dmLeaveCallButton",
    "dmAnswerCallButton",
    "dmDeclineCallButton",
    "dmLocalCallPreview",
    "dmRemoteCallList",
    "dmScreenVideo",
    "dmScreenEmpty",
    "dmList",
    "dmJumpBottomButton",
    "dmForm",
    "dmInput",
    "dmAttachment",
    "dmSelfieInput",
    "dmSelfieButton",
    "sendDmButton",
    "friendRequestForm",
    "friendUserSelect",
    "sendFriendRequestButton",
    "friendList",
    "friendRequestList",
    "friendState",
    "profileForm",
    "profileDisplayName",
    "profileAvatarUrl",
    "profileBannerUrl",
    "profileBadges",
    "profileStatus",
    "profileCustomStatus",
    "profileTheme",
    "profileBio",
    "profileInvisible",
    "saveProfileButton",
    "uploadForm",
    "fileInput",
    "filePickerSummary",
    "fileCategory",
    "privateUpload",
    "uploadButton",
    "uploadQueue",
    "uploadStatus",
    "fileList",
    "storeList",
    "orderList",
    "voiceState",
    "voiceRoomSelect",
    "joinVoiceButton",
    "joinVideoButton",
    "leaveVoiceButton",
    "muteVoiceButton",
    "deafenVoiceButton",
    "cameraVoiceButton",
    "localCallPreview",
    "voicePeerList",
    "remoteAudioList",
    "screenStatus",
    "startShareButton",
    "stopShareButton",
    "remoteVideo",
    "emptyScreen",
    "localVideo",
    "peerList",
    "vpnState",
    "vpnForm",
    "vpnUsername",
    "vpnPassword",
    "vpnLocation",
    "vpnEnabled",
    "saveVpnButton",
    "vpnLocationStatus",
    "vpnUserStatus",
    "vpnPasswordStatus",
    "serverStateText",
    "serverForm",
    "roomNameInput",
    "signupMode",
    "requireContact",
    "reportEmails",
    "serverEnabled",
    "saveServerButton",
    "shutdownServerButton",
    "restartServerButton",
    "passwordForm",
    "ownerPasswordForm",
    "createAccountForm",
    "accountManager",
    "accountSearchInput",
    "accountList",
    "currentPassword",
    "nextPassword",
    "resetUser",
    "resetPassword",
    "resetPasswordButton",
    "newAccountUsername",
    "newAccountPassword",
    "newAccountRole",
    "newAccountPersistent",
    "createAccountButton",
    "featureLockForm",
    "featureName",
    "featureMinutes",
    "featureReason",
    "saveFeatureLockButton",
    "featureLockList",
    "quickEditForm",
    "quickAppName",
    "quickNotice",
    "quickAccent",
    "quickDensity",
    "quickRounded",
    "quickCustomCss",
    "saveQuickEditButton",
    "roomForm",
    "newRoomName",
    "newRoomIcon",
    "newRoomCategory",
    "newRoomTheme",
    "newRoomPrivate",
    "newRoomInviteOnly",
    "createRoomButton",
    "roomManagerList",
    "storeItemForm",
    "storeItemName",
    "storeItemPrice",
    "storeItemCurrency",
    "storeItemPaymentLink",
    "storeItemDescription",
    "createStoreItemButton",
    "adminStoreList",
    "adminOrderList",
    "aiForm",
    "aiKeyForm",
    "aiState",
    "aiPrompt",
    "aiApiKey",
    "askAiButton",
    "saveAiKeyButton",
    "clearAiKeyButton",
    "aiResponseList",
    "adminDmFilter",
    "adminDmList",
    "createBackupButton",
    "backupList",
    "accountRequestList",
    "reportList",
    "exportModerationLogsButton",
    "moderationLogList",
    "logList",
    "exportLogsButton",
    "logSearchInput",
    "logDateInput",
    "serviceScaleForm",
    "serviceScaleList",
    "saveServiceScaleButton",
    "wipeLogsButton",
    "wipeReportsButton",
    "wipeUploadsButton",
    "wipeRoomsButton",
    "hmdState",
    "devConfigForm",
    "devEmergencyMode",
    "devMetricsEnabled",
    "devTheme",
    "saveDevConfigButton",
    "hmdMetricGrid",
    "databaseList",
    "storageList",
    "localhostToolList",
    "botForm",
    "botName",
    "botDescription",
    "botEnabled",
    "createBotButton",
    "botList",
    "pluginForm",
    "pluginName",
    "pluginHook",
    "pluginNotes",
    "pluginEnabled",
    "createPluginButton",
    "pluginList",
    "automodForm",
    "automodEnabled",
    "automodWindow",
    "automodMax",
    "automodWords",
    "saveAutomodButton",
    "toast",
  ].forEach((id) => {
    els[id] = document.getElementById(id);
  });
}

function bindEvents() {
  els.loginForm.addEventListener("submit", handleLogin);
  els.accountRequestForm.addEventListener("submit", submitAccountRequest);
  els.logoutButton.addEventListener("click", handleLogout);
  els.roomSelect.addEventListener("change", () => {
    state.selectedRoomId = els.roomSelect.value || "main";
    saveUiState();
    renderMessages();
    updateControls();
  });
  els.inviteJoinForm.addEventListener("submit", joinInvite);
  els.messageForm.addEventListener("submit", sendMessage);
  els.messageList.addEventListener("scroll", () => {
    updateJumpButton(els.messageList, els.messageJumpBottomButton);
    saveScrollPosition("messages", state.selectedRoomId || "main", els.messageList);
  });
  els.messageJumpBottomButton.addEventListener("click", () => scrollToBottom(els.messageList, true));
  els.messageSelfieButton.addEventListener("click", () => els.messageSelfieInput.click());
  els.messageSelfieInput.addEventListener("change", () => sendSelfie("message"));
  els.dmPeerSelect.addEventListener("change", () => {
    state.selectedDmUser = els.dmPeerSelect.value;
    saveUiState();
    renderDms();
    renderDmCall();
    updateControls();
  });
  els.dmForm.addEventListener("submit", sendDm);
  els.dmList.addEventListener("scroll", () => {
    updateJumpButton(els.dmList, els.dmJumpBottomButton);
    saveScrollPosition("dm", receiptTargetForCurrentDm(), els.dmList);
  });
  els.dmJumpBottomButton.addEventListener("click", () => scrollToBottom(els.dmList, true));
  els.dmSelfieButton.addEventListener("click", () => els.dmSelfieInput.click());
  els.dmSelfieInput.addEventListener("change", () => sendSelfie("dm"));
  els.dmGroupForm.addEventListener("submit", createDmGroup);
  els.deleteDmGroupButton.addEventListener("click", deleteCurrentDmGroup);
  els.dmVoiceCallButton.addEventListener("click", () => startDmCall(false));
  els.dmVideoCallButton.addEventListener("click", () => startDmCall(true));
  els.dmShareScreenButton.addEventListener("click", () => startDmScreenShare());
  els.dmStopScreenButton.addEventListener("click", () => stopShare());
  els.dmLeaveCallButton.addEventListener("click", leaveVoice);
  els.dmAnswerCallButton.addEventListener("click", answerIncomingCall);
  els.dmDeclineCallButton.addEventListener("click", clearIncomingCall);
  els.friendRequestForm.addEventListener("submit", sendFriendRequest);
  els.profileForm.addEventListener("submit", saveProfile);
  els.profileTheme.addEventListener("change", () => applyProfileTheme(els.profileTheme.value));
  els.uploadForm.addEventListener("submit", uploadFile);
  els.fileInput.addEventListener("change", () => {
    updateFilePickerSummary();
    renderUploadQueue();
  });
  els.fileList.addEventListener("dragover", (event) => event.preventDefault());
  els.fileList.addEventListener("drop", handleFileDrop);
  els.messageInput.addEventListener("input", () => sendTyping("messages", state.selectedRoomId || "main"));
  els.dmInput.addEventListener("input", () => sendTyping("dms", state.selectedDmUser || ""));
  els.joinVoiceButton.addEventListener("click", () => joinVoice(false));
  els.joinVideoButton.addEventListener("click", () => joinVoice(true));
  els.leaveVoiceButton.addEventListener("click", leaveVoice);
  els.muteVoiceButton.addEventListener("click", toggleVoiceMute);
  els.deafenVoiceButton.addEventListener("click", toggleVoiceDeafen);
  els.cameraVoiceButton.addEventListener("click", toggleVoiceCamera);
  els.startShareButton.addEventListener("click", startShare);
  els.stopShareButton.addEventListener("click", stopShare);
  els.vpnForm.addEventListener("submit", saveVpn);
  els.serverForm.addEventListener("submit", saveServer);
  els.shutdownServerButton.addEventListener("click", () => setServerPower(false));
  els.restartServerButton.addEventListener("click", () => setServerPower(true));
  els.passwordForm.addEventListener("submit", changePassword);
  els.ownerPasswordForm.addEventListener("submit", resetUserPassword);
  els.createAccountForm.addEventListener("submit", createAccount);
  els.accountSearchInput.addEventListener("input", () => {
    state.accountSearch = els.accountSearchInput.value.trim().toLowerCase();
    renderUsers();
  });
  els.featureLockForm.addEventListener("submit", saveFeatureLock);
  els.quickEditForm.addEventListener("submit", saveQuickEdit);
  els.roomForm.addEventListener("submit", createRoom);
  els.storeItemForm.addEventListener("submit", createStoreItem);
  els.aiForm.addEventListener("submit", askAi);
  els.aiKeyForm.addEventListener("submit", saveAiKey);
  els.clearAiKeyButton.addEventListener("click", clearAiKey);
  els.devConfigForm.addEventListener("submit", saveDevConfig);
  els.botForm.addEventListener("submit", createBot);
  els.pluginForm.addEventListener("submit", createPlugin);
  els.automodForm.addEventListener("submit", saveAutomod);
  els.serviceScaleForm.addEventListener("submit", saveServiceScale);
  els.adminDmFilter.addEventListener("change", () => {
    state.adminDmFilter = els.adminDmFilter.value || "all";
    renderAdminDms();
  });
  els.logSearchInput.addEventListener("input", () => {
    state.logSearch = els.logSearchInput.value.trim().toLowerCase();
    renderLogs();
    renderReports();
  });
  els.logDateInput.addEventListener("change", () => {
    state.logDate = els.logDateInput.value;
    renderLogs();
    renderReports();
  });
  els.exportLogsButton.addEventListener("click", () => exportLogs("system"));
  els.exportModerationLogsButton.addEventListener("click", () => exportLogs("moderation"));
  els.createBackupButton.addEventListener("click", createBackup);
  els.wipeLogsButton.addEventListener("click", wipeLogs);
  els.wipeReportsButton.addEventListener("click", () => wipeUtility("reports"));
  els.wipeUploadsButton.addEventListener("click", () => wipeUtility("uploads"));
  els.wipeRoomsButton.addEventListener("click", () => wipeUtility("rooms"));
  els.notificationsButton.addEventListener("click", handleNotifications);
  els.installButton.addEventListener("click", installApp);

  document.querySelectorAll(".nav-button").forEach((button) => {
    button.addEventListener("click", () => showView(button.dataset.view));
  });
  document.addEventListener("pointerdown", unlockRingtone, { once: true });
  document.querySelectorAll("[data-soundboard]").forEach((button) => {
    button.addEventListener("click", () => playSoundboard(button.dataset.soundboard, { broadcast: true }));
  });

  window.addEventListener("beforeinstallprompt", (event) => {
    event.preventDefault();
    state.installPrompt = event;
    els.installButton.textContent = "Install app";
  });

  window.addEventListener("appinstalled", () => {
    state.installPrompt = null;
    els.installButton.textContent = "Installed";
    notify("Inner installed");
  });

  window.addEventListener("popstate", () => {
    state.activeView = viewFromPath() || state.activeView || "messages";
    if (state.loggedIn) {
      showView(state.activeView, { updateHistory: false });
      renderAll();
    }
  });

  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register("/service-worker.js").catch(() => {});
  }
}

async function handleLogin(event) {
  event.preventDefault();
  els.loginError.textContent = "";

  try {
    await api("/api/login", {
      method: "POST",
      json: {
        username: els.loginUsername.value.trim(),
        password: els.loginPassword.value,
      },
    });
    els.loginPassword.value = "";
    await loadState();
  } catch (error) {
    els.loginError.textContent = error.message;
  }
}

async function submitAccountRequest(event) {
  event.preventDefault();
  els.accountRequestStatus.textContent = "Waiting for location permission";
  els.submitAccountRequestButton.disabled = true;

  try {
    const location = await getAccountRequestLocation();
    const data = await api("/api/account-requests", {
      method: "POST",
      json: {
        username: els.requestUsername.value.trim(),
        displayName: els.requestDisplayName.value.trim(),
        contact: els.requestContact.value.trim(),
        note: els.requestNote.value.trim(),
        location,
      },
    });
    els.accountRequestForm.reset();
    els.accountRequestStatus.textContent = data.request
      ? "Request sent. An admin can approve it from the Admin panel."
      : "Request sent";
  } catch (error) {
    els.accountRequestStatus.textContent = error.message || "Account request failed";
  } finally {
    els.submitAccountRequestButton.disabled = false;
  }
}

function getAccountRequestLocation() {
  if (!navigator.geolocation) {
    return Promise.reject(new Error("Location is required for server allocation, but this browser does not support it."));
  }
  return new Promise((resolve, reject) => {
    navigator.geolocation.getCurrentPosition(
      (position) => {
        resolve({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy,
        });
      },
      () => reject(new Error("Turn on location to request an account. Inner uses it for server allocation.")),
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 60000 }
    );
  });
}

async function handleLogout() {
  state.loggedIn = false;
  leaveVoice();
  closeSocket();
  stopShare({ silent: true });
  await api("/api/logout", { method: "POST" }).catch(() => {});
  showLogin();
}

async function loadState() {
  const data = await api("/api/state");
  state.user = data.user;
  state.settings = data.settings;
  if (data.rtcConfig && Array.isArray(data.rtcConfig.iceServers)) {
    rtcConfig = data.rtcConfig;
  }
  state.rooms = data.rooms || [];
  state.messages = data.messages || [];
  state.dms = data.dms || [];
  state.dmGroups = data.dmGroups || [];
  state.files = data.files || [];
  state.accountRequests = data.accountRequests || [];
  state.vpn = data.vpn || {};
  state.locations = data.locations || [];
  state.users = data.users || [];
  state.people = data.people || [];
  state.backups = data.backups || [];
  state.profiles = data.profiles || {};
  state.friends = data.friends || { friends: [], incoming: [], outgoing: [] };
  state.invites = data.invites || [];
  state.reports = data.reports || [];
  state.readReceipts = data.readReceipts || {};
  state.moderationLogs = data.moderationLogs || [];
  state.logs = data.logs || [];
  state.dev = data.dev || null;
  state.presence = data.presence || [];
  state.voiceRooms = data.voiceRooms || [];
  state.bots = data.bots || [];
  state.plugins = data.plugins || [];
  state.automod = data.automod || {};
  state.store = data.store || { items: [], orders: [] };
  state.aiRequests = data.aiRequests || [];
  state.aiConfigured = Boolean(data.aiConfigured);
  state.loggedIn = true;
  state.activeView = viewFromPath() || state.activeView || "messages";
  applyProfileTheme();
  restorePendingSends();
  applyCustomizations();

  showApp();
  showView(state.activeView, { updateHistory: false });
  renderAll();
  connectSocket();
  flushPendingSends();
  joinInviteFromUrl();
}

function showLogin(message = "") {
  state.loggedIn = false;
  applyProfileTheme("system");
  els.loginView.classList.remove("hidden");
  els.appView.classList.add("hidden");
  els.loginError.textContent = message;
  setConnection("Offline");
  setTimeout(() => els.loginPassword.focus(), 0);
}

function showApp() {
  els.loginView.classList.add("hidden");
  els.appView.classList.remove("hidden");
}

function showView(viewName, options = {}) {
  if (!viewRoutes[viewName]) viewName = "messages";
  if (viewName === "admin" && !isOwner()) viewName = "messages";
  if (viewName === "hmd" && !isDev()) viewName = "dashboard";
  state.activeView = viewName;
  saveUiState();
  if (options.updateHistory !== false) updateRoute(viewName);
  document.querySelectorAll(".nav-button").forEach((button) => {
    button.classList.toggle("active", button.dataset.view === viewName);
  });
  document.querySelectorAll(".view").forEach((view) => {
    view.classList.toggle("active", view.id === `${viewName}View`);
  });
}

async function sendMessage(event) {
  event.preventDefault();
  const text = els.messageInput.value.trim();
  const file = els.messageAttachment.files[0];
  if (!text && !file) return;

  try {
    els.sendMessageButton.disabled = true;
    const attachment = file ? await uploadChatAttachment(file) : null;
    queueOutgoingMessage({
      kind: "message",
      text,
      attachment,
      roomId: state.selectedRoomId || "main",
      parentId: state.replyToMessage ? state.replyToMessage.id : "",
    });
    els.messageInput.value = "";
    els.messageInput.placeholder = "Write a message";
    els.messageAttachment.value = "";
    state.replyToMessage = null;
  } catch (error) {
    notify(error.message);
  } finally {
    updateControls();
  }
}

async function sendDm(event) {
  event.preventDefault();
  const text = els.dmInput.value.trim();
  const target = els.dmPeerSelect.value;
  const file = els.dmAttachment.files[0];
  if (!target) return notify("Choose an account or group");
  if (!text && !file) return;

  try {
    els.sendDmButton.disabled = true;
    const attachment = file ? await uploadChatAttachment(file) : null;
    const groupId = target.startsWith("group:") ? target.slice(6) : "";
    queueOutgoingMessage({
      kind: "dm",
      to: groupId ? "" : target,
      groupId,
      text,
      attachment,
    });
    els.dmInput.value = "";
    els.dmAttachment.value = "";
    state.replyToDm = null;
  } catch (error) {
    notify(error.message);
  } finally {
    updateControls();
  }
}

async function sendSelfie(target) {
  const isDm = target === "dm";
  const input = isDm ? els.dmSelfieInput : els.messageSelfieInput;
  const file = input.files && input.files[0];
  if (!file) return;
  try {
    const attachment = await uploadChatAttachment(file);
    if (isDm) {
      const selected = els.dmPeerSelect.value;
      if (!selected) return notify("Choose an account or group");
      const groupId = selected.startsWith("group:") ? selected.slice(6) : "";
      await api("/api/dms", { method: "POST", json: { to: groupId ? "" : selected, groupId, text: "Selfie", attachment } });
    } else {
      await api("/api/messages", { method: "POST", json: { text: "Selfie", attachment, roomId: state.selectedRoomId || "main" } });
    }
    notify("Selfie sent");
  } catch (error) {
    notify(error.message);
  } finally {
    input.value = "";
    updateControls();
  }
}

async function createDmGroup(event) {
  event.preventDefault();
  const participants = Array.from(els.dmGroupMembers.querySelectorAll("input[type='checkbox']:checked")).map((input) => input.value);
  if (participants.length < 2) return notify("Choose at least two other people");
  try {
    els.createDmGroupButton.disabled = true;
    const data = await api("/api/dm-groups", {
      method: "POST",
      json: {
        name: els.dmGroupName.value.trim(),
        participants,
      },
    });
    state.dmGroups = data.dmGroups || state.dmGroups;
    state.selectedDmUser = data.group ? `group:${data.group.id}` : state.selectedDmUser;
    els.dmGroupForm.reset();
    els.dmGroupMembers.querySelectorAll("input[type='checkbox']").forEach((input) => {
      input.checked = false;
    });
    renderDms();
    notify("Group DM created");
  } catch (error) {
    notify(error.message);
  } finally {
    els.createDmGroupButton.disabled = false;
    updateControls();
  }
}

async function deleteCurrentDmGroup() {
  const group = selectedDmGroup();
  if (!group) return notify("Choose a group DM first");
  const canDelete = isOwner() || group.createdBy === state.user.username;
  if (!canDelete) return notify("Only the creator or an admin can delete this group");
  if (!window.confirm(`Delete group DM "${group.name}" and its messages?`)) return;
  try {
    const data = await api(`/api/dm-groups/${encodeURIComponent(group.id)}`, { method: "DELETE" });
    state.dmGroups = data.dmGroups || state.dmGroups.filter((entry) => entry.id !== group.id);
    state.dms = state.dms.filter((dm) => dm.groupId !== group.id);
    state.selectedDmUser = "";
    renderDms();
    renderAdminDms();
    notify("Group DM deleted");
  } catch (error) {
    notify(error.message);
  }
}

async function uploadFile(event) {
  event.preventDefault();
  const files = Array.from(els.fileInput.files || []);
  if (!files.length) return notify("Choose a file first");

  try {
    els.uploadButton.disabled = true;
    state.uploadQueue = files.map((file) => ({ name: file.name, progress: "Queued" }));
    renderUploadQueue();
    for (let index = 0; index < files.length; index += 1) {
      const file = files[index];
      state.uploadQueue[index].progress = "Uploading";
      els.uploadStatus.textContent = `Uploading ${file.name}`;
      renderUploadQueue();
      await uploadOneFile(file, els.fileCategory.value, { private: els.privateUpload.checked });
      state.uploadQueue[index].progress = "Done";
      renderUploadQueue();
    }
    els.fileInput.value = "";
    updateFilePickerSummary();
    els.uploadStatus.textContent = "";
    notify(files.length === 1 ? "File uploaded" : "Files uploaded");
  } catch (error) {
    els.uploadStatus.textContent = "";
    notify(error.message);
  } finally {
    setTimeout(() => {
      state.uploadQueue = [];
      renderUploadQueue();
    }, 1200);
    updateControls();
  }
}

async function uploadChatAttachment(file) {
  if (!file.type.startsWith("image/") && !file.type.startsWith("video/") && !file.type.startsWith("audio/")) {
    throw new Error("Chat attachments must be photos, videos, or audio");
  }
  return uploadOneFile(file, file.type.startsWith("image/") ? "image" : file.type.startsWith("audio/") ? "audio" : "video", { private: false });
}

async function uploadOneFile(file, category, options = {}) {
  const response = await fetch("/api/upload", {
    method: "POST",
    credentials: "same-origin",
    headers: {
      "x-file-name": encodeURIComponent(file.name),
      "x-file-type": file.type || "application/octet-stream",
      "x-file-category": category || "document",
      "x-file-private": options.private ? "1" : "0",
    },
    body: file,
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Attachment upload failed");
  return data.file;
}

function updateFilePickerSummary() {
  if (!els.filePickerSummary) return;
  const files = Array.from(els.fileInput.files || []);
  if (!files.length) {
    els.filePickerSummary.textContent = "No files selected";
  } else if (files.length === 1) {
    els.filePickerSummary.textContent = files[0].name;
  } else {
    els.filePickerSummary.textContent = `${files.length} files selected`;
  }
}

function renderUploadQueue() {
  if (!els.uploadQueue) return;
  els.uploadQueue.replaceChildren();
  state.uploadQueue.forEach((item) => {
    els.uploadQueue.append(adminCard(item.name, item.progress, []));
  });
}

function handleFileDrop(event) {
  event.preventDefault();
  if (!event.dataTransfer || !event.dataTransfer.files.length) return;
  els.fileInput.files = event.dataTransfer.files;
  updateFilePickerSummary();
  renderUploadQueue();
}

async function saveServer(event) {
  event.preventDefault();
  await setServerPower(els.serverEnabled.checked, { silentConfirm: true });
}

async function saveQuickEdit(event) {
  event.preventDefault();
  if (!isOwner()) return notify("Admin access required");
  try {
    const data = await api("/api/settings", {
      method: "POST",
      json: {
        roomName: els.roomNameInput.value.trim(),
        serverEnabled: els.serverEnabled.checked,
        signupMode: els.signupMode.value,
        requireContact: els.requireContact.checked,
        reportEmails: els.reportEmails.value.split(",").map((entry) => entry.trim()).filter(Boolean),
        customizations: {
          appName: els.quickAppName.value,
          notice: els.quickNotice.value,
          accent: els.quickAccent.value,
          density: els.quickDensity.value,
          rounded: els.quickRounded.checked,
          customCss: els.quickCustomCss.value,
        },
      },
    });
    state.settings = data.settings;
    applyCustomizations();
    renderAll();
    notify("Quick edit saved");
  } catch (error) {
    notify(error.message);
  }
}

async function setServerPower(enabled, options = {}) {
  if (!isOwner()) return notify("Admin access required");
  const turningOff = !enabled && state.settings.serverEnabled;
  if (turningOff && !options.silentConfirm && !window.confirm("Shutdown the server and kick members out?")) return;

  try {
    const data = await api("/api/settings", {
      method: "POST",
      json: {
        roomName: els.roomNameInput.value.trim(),
        serverEnabled: enabled,
        signupMode: els.signupMode.value,
        requireContact: els.requireContact.checked,
        reportEmails: els.reportEmails.value.split(",").map((entry) => entry.trim()).filter(Boolean),
        shutdownReason: enabled ? "" : "Admin shutdown",
      },
    });
    state.settings = data.settings;
    renderAll();
    notify(enabled ? "Server restarted" : "Server shutdown active");
  } catch (error) {
    notify(error.message);
  }
}

async function saveServiceScale(event) {
  event.preventDefault();
  if (!isOwner()) return notify("Admin access required");
  const serviceScale = {};
  els.serviceScaleList.querySelectorAll("[data-scale-key]").forEach((input) => {
    serviceScale[input.dataset.scaleKey] = Math.max(25, Math.min(200, Number(input.value || 100)));
  });
  try {
    els.saveServiceScaleButton.disabled = true;
    const data = await api("/api/settings", {
      method: "POST",
      json: {
        roomName: els.roomNameInput.value.trim(),
        serverEnabled: els.serverEnabled.checked,
        signupMode: els.signupMode.value,
        requireContact: els.requireContact.checked,
        reportEmails: els.reportEmails.value.split(",").map((entry) => entry.trim()).filter(Boolean),
        serviceScale,
      },
    });
    state.settings = data.settings;
    renderAll();
    notify("Service scaling saved");
  } catch (error) {
    notify(error.message);
  } finally {
    els.saveServiceScaleButton.disabled = false;
  }
}

async function saveVpn(event) {
  event.preventDefault();
  if (!isOwner()) return notify("Admin access required");

  try {
    const data = await api("/api/vpn", {
      method: "POST",
      json: {
        username: els.vpnUsername.value.trim(),
        password: els.vpnPassword.value,
        location: els.vpnLocation.value,
        enabled: els.vpnEnabled.checked,
      },
    });
    state.vpn = data.vpn;
    els.vpnPassword.value = "";
    renderVpn();
    notify("VPN profile saved");
  } catch (error) {
    notify(error.message);
  }
}

async function changePassword(event) {
  event.preventDefault();
  try {
    await api("/api/change-password", {
      method: "POST",
      json: {
        currentPassword: els.currentPassword.value,
        nextPassword: els.nextPassword.value,
      },
    });
    els.currentPassword.value = "";
    els.nextPassword.value = "";
    notify("Password changed");
  } catch (error) {
    notify(error.message);
  }
}

async function resetUserPassword(event) {
  event.preventDefault();
  if (!isOwner()) return notify("Admin access required");

  try {
    const data = await api("/api/users/reset-password", {
      method: "POST",
      json: {
        username: els.resetUser.value,
        nextPassword: els.resetPassword.value,
      },
    });
    state.users = data.users || state.users;
    els.resetPassword.value = "";
    renderUsers();
    notify("Password reset");
  } catch (error) {
    notify(error.message);
  }
}

async function createAccount(event) {
  event.preventDefault();
  if (!isOwner()) return notify("Admin access required");

  try {
    const data = await api("/api/users", {
      method: "POST",
      json: {
        username: els.newAccountUsername.value,
        password: els.newAccountPassword.value,
        role: els.newAccountRole.value,
        allowPersistentLogin: els.newAccountPersistent.checked,
      },
    });
    state.users = data.users || state.users;
    els.newAccountUsername.value = "";
    els.newAccountPassword.value = "";
    els.newAccountRole.value = "member";
    els.newAccountPersistent.checked = false;
    renderUsers();
    notify("Account created");
  } catch (error) {
    notify(error.message);
  }
}

async function saveFeatureLock(event) {
  event.preventDefault();
  if (!isOwner()) return notify("Admin access required");

  try {
    const data = await api("/api/features/lock", {
      method: "POST",
      json: {
        feature: els.featureName.value,
        minutes: Number(els.featureMinutes.value || 0),
        reason: els.featureReason.value,
      },
    });
    state.settings = data.settings || state.settings;
    els.featureReason.value = "";
    renderAll();
    notify(Number(els.featureMinutes.value || 0) > 0 ? "Feature locked" : "Feature unlocked");
  } catch (error) {
    notify(error.message);
  }
}

async function createRoom(event) {
  event.preventDefault();
  if (!isOwner()) return notify("Admin access required");

  try {
    const data = await api("/api/rooms", {
      method: "POST",
      json: {
        name: els.newRoomName.value,
        icon: els.newRoomIcon.value,
        category: els.newRoomCategory.value,
        theme: els.newRoomTheme.value,
        private: els.newRoomPrivate.checked,
        inviteOnly: els.newRoomInviteOnly.checked,
      },
    });
    state.rooms = data.rooms || [...state.rooms, data.room].filter(Boolean);
    state.selectedRoomId = data.room ? data.room.id : state.selectedRoomId;
    els.newRoomName.value = "";
    els.newRoomIcon.value = "";
    els.newRoomCategory.value = "";
    els.newRoomPrivate.checked = false;
    els.newRoomInviteOnly.checked = false;
    renderRooms();
    renderMessages();
    renderRoomManager();
    notify("Room created");
  } catch (error) {
    notify(error.message);
  }
}

async function createRoomInvite(roomId, roomName) {
  if (!isOwner()) return notify("Admin access required");
  const expires = window.prompt(`Invite expiry in minutes for ${roomName || "this room"}? Use 0 for no expiry.`, "1440");
  if (expires === null) return;
  const maxUses = window.prompt("Max uses? Use 0 for unlimited.", "0");
  if (maxUses === null) return;
  try {
    const data = await api("/api/rooms/invites", {
      method: "POST",
      json: {
        roomId,
        expiresMinutes: Math.max(0, Number(expires || 0)),
        maxUses: Math.max(0, Number(maxUses || 0)),
      },
    });
    const invite = data.invite;
    state.invites = data.invites || state.invites;
    const url = `${location.origin}/?invite=${encodeURIComponent(invite.code)}`;
    await copyText(`${url}\nInvite code: ${invite.code}`);
    notify(`Invite copied for ${invite.roomName || roomName}`);
  } catch (error) {
    notify(error.message);
  }
}

async function joinInvite(event) {
  event.preventDefault();
  await joinInviteCode(els.inviteCodeInput.value);
}

async function joinInviteCode(rawCode, options = {}) {
  const code = String(rawCode || "").trim();
  if (!code) return notify("Paste an invite code first");
  try {
    els.joinInviteButton.disabled = true;
    const data = await api("/api/rooms/join", { method: "POST", json: { code } });
    state.rooms = data.rooms || state.rooms;
    state.selectedRoomId = data.room ? data.room.id : state.selectedRoomId;
    els.inviteCodeInput.value = "";
    renderRooms();
    renderRoomManager();
    renderMessages();
    showView("messages");
    if (!options.silent) notify(`Joined ${data.room ? data.room.name : "room"}`);
  } catch (error) {
    notify(error.message);
  } finally {
    els.joinInviteButton.disabled = false;
  }
}

function joinInviteFromUrl() {
  if (state.inviteAutoJoined) return;
  const params = new URLSearchParams(location.search);
  const invite = params.get("invite");
  if (!invite) return;
  state.inviteAutoJoined = true;
  params.delete("invite");
  const nextSearch = params.toString();
  history.replaceState({}, "", `${location.pathname}${nextSearch ? `?${nextSearch}` : ""}${location.hash || ""}`);
  joinInviteCode(invite, { silent: true });
}

async function createStoreItem(event) {
  event.preventDefault();
  if (!isOwner()) return notify("Admin access required");
  try {
    const data = await api("/api/store/items", {
      method: "POST",
      json: {
        name: els.storeItemName.value,
        description: els.storeItemDescription.value,
        priceCents: Math.round(Number(els.storeItemPrice.value || 0) * 100),
        currency: els.storeItemCurrency.value,
        paymentLink: els.storeItemPaymentLink.value,
      },
    });
    state.store = data.store || state.store;
    els.storeItemName.value = "";
    els.storeItemPrice.value = "";
    els.storeItemPaymentLink.value = "";
    els.storeItemDescription.value = "";
    renderStore();
    renderAdminStore();
    notify("Paid item created");
  } catch (error) {
    notify(error.message);
  }
}

async function askAi(event) {
  event.preventDefault();
  if (!isOwner()) return notify("Admin access required");
  try {
    els.askAiButton.disabled = true;
    const data = await api("/api/ai/suggest", {
      method: "POST",
      json: { prompt: els.aiPrompt.value },
    });
    state.aiRequests = data.aiRequests || state.aiRequests;
    els.aiPrompt.value = "";
    renderAiRequests();
    notify(data.request && data.request.configured ? "AI answered" : "AI request saved");
  } catch (error) {
    notify(error.message);
  } finally {
    els.askAiButton.disabled = false;
  }
}

async function saveAiKey(event) {
  event.preventDefault();
  if (!isOwner()) return notify("Admin access required");
  try {
    const data = await api("/api/ai/key", {
      method: "POST",
      json: { apiKey: els.aiApiKey.value },
    });
    state.aiConfigured = Boolean(data.aiConfigured);
    els.aiApiKey.value = "";
    renderAiRequests();
    notify("AI key saved");
  } catch (error) {
    notify(error.message);
  }
}

async function clearAiKey() {
  if (!isOwner()) return notify("Admin access required");
  try {
    const data = await api("/api/ai/key", {
      method: "POST",
      json: { mode: "clear" },
    });
    state.aiConfigured = Boolean(data.aiConfigured);
    els.aiApiKey.value = "";
    renderAiRequests();
    notify("Saved AI key cleared");
  } catch (error) {
    notify(error.message);
  }
}

async function saveDevConfig(event) {
  event.preventDefault();
  if (!isDev()) return notify("HMD/dev access required");
  try {
    const data = await api("/api/dev/config", {
      method: "POST",
      json: {
        emergencyMode: els.devEmergencyMode.checked,
        metricsEnabled: els.devMetricsEnabled.checked,
        theme: els.devTheme.value,
      },
    });
    state.dev = { ...(state.dev || {}), devConfig: data.devConfig };
    renderHmd();
    notify("HMD settings saved");
  } catch (error) {
    notify(error.message);
  }
}

async function createBot(event) {
  event.preventDefault();
  if (!isDev()) return notify("HMD/dev access required");
  try {
    const data = await api("/api/dev/bots", {
      method: "POST",
      json: {
        name: els.botName.value,
        description: els.botDescription.value,
        enabled: els.botEnabled.checked,
      },
    });
    state.bots = data.bots || [];
    els.botName.value = "";
    els.botDescription.value = "";
    renderHmd();
  } catch (error) {
    notify(error.message);
  }
}

async function createPlugin(event) {
  event.preventDefault();
  if (!isDev()) return notify("HMD/dev access required");
  try {
    const data = await api("/api/dev/plugins", {
      method: "POST",
      json: {
        name: els.pluginName.value,
        hook: els.pluginHook.value,
        notes: els.pluginNotes.value,
        enabled: els.pluginEnabled.checked,
      },
    });
    state.plugins = data.plugins || [];
    els.pluginName.value = "";
    els.pluginHook.value = "";
    els.pluginNotes.value = "";
    renderHmd();
  } catch (error) {
    notify(error.message);
  }
}

async function saveAutomod(event) {
  event.preventDefault();
  if (!isOwner()) return notify("Moderator access required");
  try {
    const words = els.automodWords.value.split(/\n|,/).map((word) => word.trim()).filter(Boolean);
    const data = await api("/api/automod", {
      method: "POST",
      json: {
        enabled: els.automodEnabled.checked,
        spamWindowSeconds: Number(els.automodWindow.value || 8),
        maxMessagesPerWindow: Number(els.automodMax.value || 6),
        mutedWords: words,
      },
    });
    state.automod = data.automod || {};
    renderHmd();
    notify("Automod saved");
  } catch (error) {
    notify(error.message);
  }
}

async function createBackup() {
  if (!isOwner()) return notify("Admin access required");

  try {
    const data = await api("/api/backups", { method: "POST" });
    state.backups = data.backups || state.backups;
    renderBackups();
    notify("Backup created");
  } catch (error) {
    notify(error.message);
  }
}

async function wipeLogs() {
  if (!isOwner()) return notify("Admin access required");
  if (!window.confirm("Wipe system and moderation logs? This cannot be undone.")) return;
  const confirm = window.prompt("Type WIPE to clear logs") || "";
  try {
    const data = await api("/api/logs/wipe", {
      method: "POST",
      json: { confirm },
    });
    state.logs = data.logs || [];
    state.moderationLogs = data.moderationLogs || [];
    renderReports();
    renderLogs();
    notify("Logs wiped");
  } catch (error) {
    notify(error.message);
  }
}

async function wipeUtility(kind) {
  if (!isOwner()) return notify("Admin access required");
  const label = kind === "uploads" ? "uploaded files" : kind === "rooms" ? "rooms" : "reports";
  if (!window.confirm(`Clear ${label}? This cannot be undone.`)) return;
  const confirm = window.prompt("Type WIPE to continue") || "";
  try {
    const data = await api(`/api/wipe/${kind}`, {
      method: "POST",
      json: { confirm },
    });
    if (kind === "reports") {
      state.reports = data.reports || [];
      renderReports();
    } else if (kind === "uploads") {
      state.files = data.files || [];
      renderFiles();
      renderShell();
    } else if (kind === "rooms") {
      state.rooms = data.rooms || state.rooms;
      state.selectedRoomId = "main";
      renderRooms();
      renderMessages();
    }
    notify(`${label} cleared`);
  } catch (error) {
    notify(error.message);
  }
}

async function installApp() {
  if (!state.installPrompt) {
    if (window.matchMedia && window.matchMedia("(display-mode: standalone)").matches) {
      return notify("Inner is already installed");
    }
    return notify("Use the browser menu to install Inner. Browser install works best on localhost or HTTPS.");
  }
  state.installPrompt.prompt();
  await state.installPrompt.userChoice.catch(() => {});
  state.installPrompt = null;
  els.installButton.textContent = "Install app";
}

async function handleNotifications() {
  if (!("Notification" in window)) {
    return notify("This browser does not support system alerts. In-app popups still work.");
  }
  if (!window.isSecureContext) {
    return notify("System alerts need localhost or HTTPS. In-app popups still work on this link.");
  }
  if (Notification.permission === "denied") {
    return notify("Alerts are blocked in browser settings");
  }
  if (Notification.permission !== "granted") {
    const permission = await Notification.requestPermission();
    if (permission !== "granted") return notify("Alerts were not enabled");
  }

  state.notificationsEnabled = !state.notificationsEnabled;
  setStoredFlag("innerNotifications", state.notificationsEnabled);
  updateNotificationButton();
  notify(state.notificationsEnabled ? "Alerts enabled" : "Alerts disabled");
}

function connectSocket() {
  if (!window.location.host) {
    setConnection("Open from server");
    return;
  }
  closeSocket();
  const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
  const ws = new WebSocket(`${protocol}//${window.location.host}/ws`);
  state.ws = ws;

  ws.addEventListener("open", () => {
    const wasReconnect = state.wsEverConnected;
    state.wsEverConnected = true;
    setConnection("Live");
    flushWsOutbox();
    recoverRealtimeState(wasReconnect).catch(() => {});
    clearInterval(state.wsPingTimer);
    state.wsPingTimer = setInterval(() => {
      if (state.ws === ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: "ping", at: Date.now() }));
      }
    }, 25000);
  });
  ws.addEventListener("close", () => {
    if (state.ws !== ws) return;
    clearInterval(state.wsPingTimer);
    state.wsPingTimer = null;
    setConnection("Offline");
    if (state.loggedIn) {
      clearTimeout(state.reconnectTimer);
      state.reconnectTimer = setTimeout(connectSocket, 1600);
    }
  });
  ws.addEventListener("error", () => setConnection("Offline"));
  ws.addEventListener("message", (event) => {
    try {
      handleSocketMessage(JSON.parse(event.data));
    } catch (error) {
      notify("Could not read live update");
    }
  });
}

function closeSocket() {
  clearTimeout(state.reconnectTimer);
  state.reconnectTimer = null;
  clearInterval(state.wsPingTimer);
  state.wsPingTimer = null;
  if (state.ws) {
    const ws = state.ws;
    state.ws = null;
    ws.close();
  }
  state.peers.clear();
  state.voicePeers = [];
  state.peerLocations.clear();
  renderPeers();
}

function handleSocketMessage(message) {
  if (message.type === "hello") {
    state.clientId = message.clientId;
    state.peers = new Map((message.peers || []).map((peer) => [peer.id, peer]));
    state.voicePeers = (message.peers || []).filter((peer) => peer.voiceRoomId);
    state.presence = message.presence || state.presence;
    renderPeers();
    renderVoice();
    renderDmCall();
    renderDashboard();
    return;
  }

  if (message.type === "peer:joined") {
    state.peers.set(message.peer.id, message.peer);
    if (message.peer.voiceRoomId) mergeVoicePeers(message.peer.voiceRoomId, [message.peer]);
    renderPeers();
    renderVoice();
    renderDmCall();
    if (state.localStream && canPeerReceiveScreen(message.peer)) makeOffer(message.peer.id, state.screenRoomId || "screen:global");
    return;
  }

  if (message.type === "peer:left") {
    state.peers.delete(message.peerId);
    state.voicePeers = state.voicePeers.filter((peer) => peer.id !== message.peerId);
    closePeer(message.peerId);
    closeVoicePeer(message.peerId);
    if (state.remoteFrom === message.peerId) clearRemoteVideo();
    renderPeers();
    renderVoice();
    renderDmCall();
    return;
  }

  if (message.type === "message:new") {
    const incoming = state.user && message.message && message.message.user !== state.user.username;
    addMessage(message.message);
    if (incoming) showIncomingMessageAlert(message.message);
    return;
  }

  if (message.type === "message:delete") {
    state.messages = state.messages.filter((entry) => entry.id !== message.id);
    renderShell();
    renderMessages();
    return;
  }

  if (message.type === "message:update") {
    const index = state.messages.findIndex((entry) => entry.id === message.message.id);
    if (index !== -1) state.messages[index] = message.message;
    renderMessages();
    return;
  }

  if (message.type === "room:new") {
    if (!state.rooms.some((room) => room.id === message.room.id)) state.rooms.push(message.room);
    renderRooms();
    return;
  }

  if (message.type === "room:delete") {
    state.rooms = state.rooms.filter((room) => room.id !== message.id);
    state.messages = state.messages.filter((entry) => (entry.roomId || "main") !== message.id);
    if (state.selectedRoomId === message.id) state.selectedRoomId = "main";
    renderRooms();
    renderMessages();
    return;
  }

  if (message.type === "rooms:update") {
    state.rooms = message.rooms || state.rooms;
    renderRooms();
    renderRoomManager();
    return;
  }

  if (message.type === "dm:new") {
    const incoming = state.user && message.dm && message.dm.from !== state.user.username;
    addDm(message.dm);
    if (incoming) showIncomingDmAlert(message.dm);
    return;
  }

  if (message.type === "dm:update") {
    const index = state.dms.findIndex((entry) => entry.id === message.dm.id);
    if (index !== -1) state.dms[index] = message.dm;
    renderDms();
    renderAdminDms();
    return;
  }

  if (message.type === "dm-groups:update") {
    state.dmGroups = message.dmGroups || [];
    renderDms();
    renderAdminDms();
    return;
  }

  if (message.type === "dm-group:delete") {
    state.dmGroups = state.dmGroups.filter((entry) => entry.id !== message.id);
    state.dms = state.dms.filter((entry) => entry.groupId !== message.id);
    if (state.selectedDmUser === `group:${message.id}`) state.selectedDmUser = "";
    renderDms();
    renderAdminDms();
    return;
  }

  if (message.type === "dm:delete") {
    state.dms = state.dms.filter((entry) => entry.id !== message.id);
    renderDms();
    renderAdminDms();
    return;
  }

  if (message.type === "file:new") {
    addFile(message.file);
    return;
  }

  if (message.type === "file:delete") {
    state.files = state.files.filter((entry) => entry.id !== message.id);
    renderShell();
    renderFiles();
    return;
  }

  if (message.type === "users:update" && isOwner()) {
    state.users = message.users || [];
    state.people = message.users || state.people;
    renderUsers();
    renderDms();
    renderAdminDms();
    return;
  }

  if (message.type === "files:wipe") {
    state.files = [];
    renderShell();
    renderFiles();
    return;
  }

  if (message.type === "profiles:update") {
    state.profiles = message.profiles || state.profiles;
    renderProfile();
    applyProfileTheme();
    renderFriends();
    renderDashboard();
    return;
  }

  if (message.type === "friends:update") {
    state.friends = message.friends || state.friends;
    renderFriends();
    renderDashboard();
    return;
  }

  if (message.type === "presence:update") {
    state.presence = message.presence || [];
    renderDashboard();
    renderPeers();
    return;
  }

  if (message.type === "typing") {
    if (message.active && message.username !== state.user.username) notify(`${message.username} is typing`);
    return;
  }

  if (message.type === "state:update") {
    state.settings = message.settings;
    if (!state.settings.serverEnabled && !isOwner()) {
      leaveVoice();
      stopShare({ silent: true });
      closeSocket();
      showLogin("Server shutdown is active. Admin, HMD, and dev accounts can stay connected.");
      return;
    }
    if (!state.settings.serverEnabled && state.localStream) stopShare();
    applyCustomizations();
    renderAll();
    return;
  }

  if (message.type === "backups:update" && isOwner()) {
    state.backups = message.backups || [];
    renderBackups();
    return;
  }

  if (message.type === "account-requests:update" && isOwner()) {
    state.accountRequests = message.accountRequests || [];
    renderAccountRequests();
    renderHmd();
    return;
  }

  if (message.type === "reports:update" && isOwner()) {
    state.reports = message.reports || [];
    renderReports();
    return;
  }

  if (message.type === "moderation:update" && isOwner()) {
    state.moderationLogs = message.moderationLogs || [];
    renderReports();
    return;
  }

  if (message.type === "logs:update" && isOwner()) {
    state.logs = message.logs || [];
    renderLogs();
    return;
  }

  if (message.type === "dev:update" && isDev()) {
    state.dev = { ...(state.dev || {}), devConfig: message.devConfig || {} };
    renderHmd();
    return;
  }

  if (message.type === "bots:update" && isDev()) {
    state.bots = message.bots || [];
    renderHmd();
    return;
  }

  if (message.type === "plugins:update" && isDev()) {
    state.plugins = message.plugins || [];
    renderHmd();
    return;
  }

  if (message.type === "automod:update" && isOwner()) {
    state.automod = message.automod || {};
    renderHmd();
    return;
  }

  if (message.type === "store:update") {
    state.store = message.store || { items: [], orders: [] };
    renderStore();
    renderAdminStore();
    return;
  }

  if (message.type === "ai:update" && isOwner()) {
    state.aiRequests = message.aiRequests || [];
    renderAiRequests();
    return;
  }

  if (message.type === "vpn:update") {
    state.vpn = message.vpn;
    renderVpn();
    return;
  }

  if (message.type === "screen:status") {
    const peer = state.peers.get(message.from) || {
      id: message.from,
      username: message.fromUser,
    };
    peer.sharing = message.sharing;
    peer.screenRoomId = message.roomId || "";
    state.peers.set(message.from, peer);
    if (!message.sharing && state.remoteFrom === message.from) clearRemoteVideo(message.roomId);
    if (message.sharing && isDmCallRoom(message.roomId) && message.from !== state.clientId) {
      showLiveAlert(`${peer.username || "Someone"} is sharing a screen in ${callRoomLabel(message.roomId)}`);
    }
    renderPeers();
    renderDmCall();
    return;
  }

  if (message.type === "voice:update") {
    mergeVoicePeers(message.roomId || state.voiceRoomId || "lobby", message.peers || []);
    if (message.leftPeerId) closeVoicePeer(message.leftPeerId);
    syncVoicePeers(message.joinedPeerId).catch((error) => notify(error.message || "Call sync failed"));
    renderVoice();
    renderDmCall();
    return;
  }

  if (message.type === "voice:rooms") {
    state.voiceRooms = message.voiceRooms || state.voiceRooms;
    renderVoice();
    return;
  }

  if (message.type === "read-receipts:update") {
    state.readReceipts = { ...(state.readReceipts || {}), ...(message.receipts || {}) };
    renderMessages();
    renderDms();
    return;
  }

  if (message.type === "voice:signal") {
    handleVoiceSignal(message.from, message.signal, message.roomId).catch((error) => notify(error.message || "Voice signal failed"));
    return;
  }

  if (message.type === "signal") {
    handleSignal(message.from, message.fromUser, message.signal, message.roomId).catch((error) => {
      notify(error.message || "Screen share signal failed");
    });
    return;
  }

  if (message.type === "call:invite") {
    handleCallInvite(message);
    return;
  }

  if (message.type === "soundboard:play") {
    if (message.from !== state.clientId) {
      playSoundboard(message.sound, { broadcast: false });
      showLiveAlert(`${message.fromUser || "Someone"} played ${message.sound || "a sound"}`, { title: "Soundboard" });
    }
    return;
  }

  if (message.type === "screen:request") {
    answerScreenRequest(message.from, message.fromUser);
    return;
  }

  if (message.type === "location:request") {
    answerLocationRequest(message.from, message.fromUser);
    return;
  }

  if (message.type === "location:share") {
    const peer = state.peers.get(message.from) || { id: message.from, username: message.fromUser || "Peer" };
    peer.location = message.location;
    state.peers.set(message.from, peer);
    if (message.location) state.peerLocations.set(message.from, message.location);
    renderPeers();
    notify(`${peer.username} shared location`);
    return;
  }

  if (message.type === "error") {
    notify(message.error);
    return;
  }

  if (message.type === "server:shutdown") {
    leaveVoice();
    stopShare({ silent: true });
    closeSocket();
    showLogin(message.error || "Server shutdown is active.");
  }
}

async function startShare(options = {}) {
  if (!state.settings.serverEnabled && !isOwner()) return notify("Server room is off");
  if (!featureAvailable("screen")) return notify(lockMessage("screen"));
  if (!(await ensureRealtimeReady("screen sharing"))) return;
  if (!window.isSecureContext) return notify("Screen sharing needs HTTPS or localhost.");
  if (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia) {
    return notify("Screen sharing is not available in this browser");
  }

  try {
    let stream;
    try {
      stream = await navigator.mediaDevices.getDisplayMedia({
        video: { cursor: "always" },
        audio: true,
      });
    } catch (error) {
      stream = await navigator.mediaDevices.getDisplayMedia({
        video: true,
        audio: false,
      });
    }
    if (state.localStream) stopShare({ silent: true });
    const roomId = options.roomId || "screen:global";
    state.screenRoomId = roomId;
    state.localStream = stream;
    els.localVideo.srcObject = stream;
    playMedia(els.localVideo);
    stream.getTracks().forEach((track) => {
      track.addEventListener("ended", () => stopShare());
    });
    if (!sendWs({ type: "screen:status", sharing: true, roomId })) {
      stopShare({ silent: true });
      return notify("Live connection is not ready");
    }
    for (const peer of screenPeersForRoom(roomId)) {
      await makeOffer(peer.id, roomId);
    }
    renderScreen();
    renderDmCall();
  } catch (error) {
    notify(error.message || "Screen sharing was cancelled");
  }
}

async function answerScreenRequest(target, fromUser) {
  if (!window.confirm(`${fromUser || "Admin"} is requesting your screen. Share it now?`)) return;
  await startShare();
  if (target && state.localStream) makeOffer(target).catch(() => {});
}

function answerLocationRequest(target, fromUser) {
  if (!navigator.geolocation) return notify("Location is not available in this browser");
  if (!window.confirm(`${fromUser || "Admin"} is requesting your location. Share it now?`)) return;

  navigator.geolocation.getCurrentPosition(
    (position) => {
      sendWs({
        type: "location:share",
        target,
        location: {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy,
        },
      });
      notify("Location shared");
    },
    (error) => notify(error.message || "Location sharing failed"),
    { enableHighAccuracy: true, timeout: 15000, maximumAge: 30000 }
  );
}

function requestPeerScreen(peerId) {
  if (!isOwner()) return notify("Admin access required");
  sendWs({ type: "screen:request", target: peerId });
  notify("Screen request sent");
}

function requestPeerLocation(peerId) {
  if (!isOwner()) return notify("Admin access required");
  sendWs({ type: "location:request", target: peerId });
  notify("Location request sent");
}

async function getCallMedia(videoEnabled) {
  if (!videoEnabled) return navigator.mediaDevices.getUserMedia({ audio: true, video: false });
  try {
    return await navigator.mediaDevices.getUserMedia({
      audio: true,
      video: { width: { ideal: 960 }, height: { ideal: 540 }, facingMode: "user" },
    });
  } catch (error) {
    return navigator.mediaDevices.getUserMedia({ audio: true, video: true });
  }
}

async function startDmCall(videoEnabled) {
  const roomId = currentDmCallRoom();
  if (!roomId) return notify("Choose a DM or group first");
  const joined = await joinVoice(videoEnabled, { roomId, invite: true, roomLabel: currentDmCallLabel() });
  if (joined) {
    showLiveAlert(`${videoEnabled ? "Video" : "Voice"} call started in ${currentDmCallLabel()}`);
  }
}

async function startDmScreenShare() {
  const roomId = currentDmCallRoom();
  if (!roomId) return notify("Choose a DM or group first");
  await startShare({ roomId });
}

async function answerIncomingCall() {
  if (!state.incomingCall) return;
  const call = state.incomingCall;
  selectDmFromCallRoom(call.roomId);
  clearIncomingCall({ silent: true });
  showView("dms");
  await joinVoice(call.mode === "video", { roomId: call.roomId, roomLabel: call.roomLabel || callRoomLabel(call.roomId) });
}

function clearIncomingCall(options = {}) {
  state.incomingCall = null;
  stopRingtone();
  renderDmCall();
  if (!options.silent) notify("Call dismissed");
}

function handleCallInvite(message) {
  if (!message || message.from === state.clientId) return;
  state.incomingCall = message;
  showLiveAlert(`${message.fromUser || "Someone"} is calling ${message.roomLabel || callRoomLabel(message.roomId)}`, {
    title: `${message.mode === "video" ? "Video" : "Voice"} call`,
  });
  playRingtone();
  renderDmCall();
}

async function joinVoice(videoEnabled = false, options = {}) {
  if (!featureAvailable("voice")) return notify(lockMessage("voice"));
  if (!(await ensureRealtimeReady(videoEnabled ? "video chat" : "voice chat"))) return;
  if (!window.isSecureContext) return notify("Voice and video need HTTPS or localhost.");
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return notify("Voice is not available in this browser");
  try {
    const roomId = options.roomId || els.voiceRoomSelect.value || "lobby";
    if (state.voiceStream && state.voiceRoomId !== roomId) leaveVoice();
    state.voiceRoomId = roomId;
    state.voiceVideoEnabled = Boolean(videoEnabled);
    state.voiceCameraOff = !videoEnabled;
    state.voiceStream = await getCallMedia(videoEnabled);
    state.voiceStream.getAudioTracks().forEach((track) => {
      track.enabled = !state.voiceMuted;
    });
    state.voiceStream.getVideoTracks().forEach((track) => {
      track.enabled = !state.voiceCameraOff;
    });
    if (els.localCallPreview) {
      els.localCallPreview.srcObject = state.voiceStream;
      playMedia(els.localCallPreview);
    }
    if (els.dmLocalCallPreview) {
      els.dmLocalCallPreview.srcObject = state.voiceStream;
      playMedia(els.dmLocalCallPreview);
    }
    if (!sendWs({
      type: "voice:join",
      roomId: state.voiceRoomId,
      muted: state.voiceMuted,
      deafened: state.voiceDeafened,
      videoEnabled: state.voiceVideoEnabled,
      cameraOff: state.voiceCameraOff,
    })) {
      state.voiceStream.getTracks().forEach((track) => track.stop());
      state.voiceStream = null;
      return notify("Live connection is not ready");
    }
    if (options.invite) {
      sendWs({ type: "call:invite", roomId: state.voiceRoomId, mode: videoEnabled ? "video" : "voice", roomLabel: options.roomLabel || callRoomLabel(state.voiceRoomId) });
    }
    renderVoice();
    renderDmCall();
    return true;
  } catch (error) {
    notify(error.message || "Could not join voice");
    return false;
  }
}

function leaveVoice() {
  sendWs({ type: "voice:leave" });
  if (state.voiceStream) state.voiceStream.getTracks().forEach((track) => track.stop());
  state.voiceStream = null;
  state.voiceVideoEnabled = false;
  state.voiceCameraOff = true;
  if (els.localCallPreview) els.localCallPreview.srcObject = null;
  if (els.dmLocalCallPreview) els.dmLocalCallPreview.srcObject = null;
  for (const pc of state.voiceConnections.values()) pc.close();
  state.voiceConnections.clear();
  state.voicePendingCandidates.clear();
  if (els.remoteAudioList) els.remoteAudioList.replaceChildren();
  if (els.dmRemoteCallList) els.dmRemoteCallList.replaceChildren();
  renderVoice();
  renderDmCall();
}

function toggleVoiceMute() {
  state.voiceMuted = !state.voiceMuted;
  if (state.voiceStream) {
    state.voiceStream.getAudioTracks().forEach((track) => {
      track.enabled = !state.voiceMuted;
    });
  }
  sendWs({
    type: "voice:state",
    muted: state.voiceMuted,
    deafened: state.voiceDeafened,
    videoEnabled: state.voiceVideoEnabled,
    cameraOff: state.voiceCameraOff,
  });
  renderVoice();
}

function toggleVoiceDeafen() {
  state.voiceDeafened = !state.voiceDeafened;
  if (els.remoteAudioList) {
    els.remoteAudioList.querySelectorAll("audio").forEach((audio) => {
      audio.muted = state.voiceDeafened;
    });
  }
  sendWs({
    type: "voice:state",
    muted: state.voiceMuted,
    deafened: state.voiceDeafened,
    videoEnabled: state.voiceVideoEnabled,
    cameraOff: state.voiceCameraOff,
  });
  renderVoice();
}

function toggleVoiceCamera() {
  if (!state.voiceStream || !state.voiceVideoEnabled) return;
  state.voiceCameraOff = !state.voiceCameraOff;
  state.voiceStream.getVideoTracks().forEach((track) => {
    track.enabled = !state.voiceCameraOff;
  });
  sendWs({
    type: "voice:state",
    muted: state.voiceMuted,
    deafened: state.voiceDeafened,
    videoEnabled: state.voiceVideoEnabled,
    cameraOff: state.voiceCameraOff,
  });
  renderVoice();
}

async function syncVoicePeers(joinedPeerId = "") {
  if (!state.voiceStream || !state.voiceRoomId) return;
  if (joinedPeerId && joinedPeerId === state.clientId) return;
  const peers = state.voicePeers.filter((peer) => peer.id !== state.clientId && peer.voiceRoomId === state.voiceRoomId);
  for (const peer of peers) {
    if (joinedPeerId && joinedPeerId !== state.clientId && peer.id !== joinedPeerId) continue;
    if (!state.voiceConnections.has(peer.id)) await makeVoiceOffer(peer.id);
  }
}

async function makeVoiceOffer(peerId) {
  if (!state.voiceStream) return;
  const pc = createVoicePeer(peerId);
  addStreamTracks(pc, state.voiceStream);
  const offer = await pc.createOffer();
  await pc.setLocalDescription(offer);
  sendWs({ type: "voice:signal", target: peerId, roomId: state.voiceRoomId, videoEnabled: state.voiceVideoEnabled, signal: pc.localDescription });
}

function createVoicePeer(peerId) {
  const existing = state.voiceConnections.get(peerId);
  if (existing && existing.roomId === state.voiceRoomId && existing.signalingState !== "closed") return existing;
  if (existing) existing.close();
  const pc = new RTCPeerConnection(rtcConfig);
  pc.roomId = state.voiceRoomId;
  state.voiceConnections.set(peerId, pc);
  pc.onicecandidate = (event) => {
    if (event.candidate) sendWs({ type: "voice:signal", target: peerId, roomId: state.voiceRoomId, signal: { candidate: event.candidate } });
  };
  pc.ontrack = (event) => {
    attachCallStream(peerId, event.streams[0]);
  };
  pc.onconnectionstatechange = renderVoice;
  pc.oniceconnectionstatechange = renderVoice;
  return pc;
}

async function handleVoiceSignal(from, signal, roomId = "") {
  if (roomId && state.voiceRoomId && roomId !== state.voiceRoomId) return;
  if (!state.voiceStream && signal && signal.type === "offer") return;
  let pc = state.voiceConnections.get(from);
  if (!pc) {
    pc = createVoicePeer(from);
    if (state.voiceStream) {
      addStreamTracks(pc, state.voiceStream);
    }
  }
  if (signal.candidate) {
    if (pc.remoteDescription) await pc.addIceCandidate(signal.candidate);
    else {
      const pending = state.voicePendingCandidates.get(from) || [];
      pending.push(signal.candidate);
      state.voicePendingCandidates.set(from, pending);
    }
    return;
  }
  await pc.setRemoteDescription(signal);
  if (signal.type === "offer") {
    const answer = await pc.createAnswer();
    await pc.setLocalDescription(answer);
    sendWs({ type: "voice:signal", target: from, roomId: state.voiceRoomId, videoEnabled: state.voiceVideoEnabled, signal: pc.localDescription });
  }
  const pending = state.voicePendingCandidates.get(from) || [];
  for (const candidate of pending) await pc.addIceCandidate(candidate);
  state.voicePendingCandidates.delete(from);
}

function attachCallStream(peerId, stream) {
  if (!stream) return;
  const container = isDmCallRoom(state.voiceRoomId) ? els.dmRemoteCallList : els.remoteAudioList;
  const otherContainer = isDmCallRoom(state.voiceRoomId) ? els.remoteAudioList : els.dmRemoteCallList;
  if (otherContainer) {
    const old = otherContainer.querySelector(`[data-call-peer="${CSS.escape(peerId)}"]`);
    if (old) old.remove();
  }
  if (!container) return;
  let tile = container.querySelector(`[data-call-peer="${CSS.escape(peerId)}"]`);
  const peer = state.peers.get(peerId) || state.voicePeers.find((entry) => entry.id === peerId) || {};
  if (!tile) {
    tile = document.createElement("article");
    tile.className = "call-tile";
    tile.dataset.callPeer = peerId;
    const video = document.createElement("video");
    video.autoplay = true;
    video.playsInline = true;
    video.muted = true;
    const audio = document.createElement("audio");
    audio.autoplay = true;
    audio.playsInline = true;
    const name = document.createElement("strong");
    name.textContent = peer.username || "Caller";
    tile.append(video, audio, name);
    container.append(tile);
  }
  const video = tile.querySelector("video");
  const audio = tile.querySelector("audio");
  const hasVideo = stream.getVideoTracks().length > 0;
  video.muted = true;
  video.srcObject = stream;
  video.classList.toggle("hidden", !hasVideo);
  audio.srcObject = stream;
  audio.muted = state.voiceDeafened;
  playMedia(video);
  playMedia(audio);
  renderDmCall();
}

function closeVoicePeer(peerId) {
  const pc = state.voiceConnections.get(peerId);
  if (pc) pc.close();
  state.voiceConnections.delete(peerId);
  state.voicePendingCandidates.delete(peerId);
  const tile = document.getElementById(`call-${peerId}`);
  if (tile) tile.remove();
  document.querySelectorAll(`[data-call-peer="${CSS.escape(peerId)}"]`).forEach((entry) => entry.remove());
}

function stopShare(options = {}) {
  const stream = state.localStream;
  const roomId = state.screenRoomId || "screen:global";
  state.localStream = null;
  state.screenRoomId = "";
  if (stream) {
    stream.getTracks().forEach((track) => track.stop());
  }
  els.localVideo.srcObject = null;

  for (const [peerId, pc] of state.peerConnections) {
    if (pc.hasLocalShare) closePeer(peerId);
  }

  if (!options.silent) sendWs({ type: "screen:status", sharing: false, roomId });
  renderScreen();
  renderDmCall();
}

async function makeOffer(peerId, roomId = state.screenRoomId || "screen:global") {
  const pc = createPeer(peerId, roomId);
  if (state.localStream) {
    addStreamTracks(pc, state.localStream);
    pc.hasLocalShare = true;
  }
  const offer = await pc.createOffer();
  await pc.setLocalDescription(offer);
  sendSignal(peerId, { description: pc.localDescription }, roomId);
}

function createPeer(peerId, roomId = "screen:global") {
  const existing = state.peerConnections.get(peerId);
  if (existing && existing.roomId === roomId && existing.signalingState !== "closed") return existing;
  if (existing) existing.close();

  const pc = new RTCPeerConnection(rtcConfig);
  pc.roomId = roomId;
  pc.hasLocalShare = false;
  pc.onicecandidate = (event) => {
    if (event.candidate) sendSignal(peerId, { candidate: event.candidate }, roomId);
  };
  pc.ontrack = (event) => {
    const stream = event.streams[0];
    if (!stream) return;
    attachScreenStream(peerId, stream, roomId);
  };
  pc.onconnectionstatechange = renderScreen;

  if (state.localStream) {
    addStreamTracks(pc, state.localStream);
    pc.hasLocalShare = true;
  }

  state.peerConnections.set(peerId, pc);
  return pc;
}

async function handleSignal(from, fromUser, signal, roomId = "screen:global") {
  const peer = state.peers.get(from) || { id: from, username: fromUser || "Peer", sharing: false };
  state.peers.set(from, peer);
  const pc = createPeer(from, roomId);

  if (signal.description) {
    await pc.setRemoteDescription(signal.description);
    await flushCandidates(from, pc);
    if (signal.description.type === "offer") {
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      sendSignal(from, { description: pc.localDescription }, roomId);
    }
  }

  if (signal.candidate) {
    if (pc.remoteDescription) {
      await pc.addIceCandidate(signal.candidate);
    } else {
      const pending = state.pendingCandidates.get(from) || [];
      pending.push(signal.candidate);
      state.pendingCandidates.set(from, pending);
    }
  }

  renderPeers();
}

async function flushCandidates(peerId, pc) {
  const pending = state.pendingCandidates.get(peerId) || [];
  state.pendingCandidates.delete(peerId);
  for (const candidate of pending) {
    await pc.addIceCandidate(candidate);
  }
}

function sendSignal(target, signal, roomId = state.screenRoomId || "screen:global") {
  sendWs({ type: "signal", target, roomId, signal });
}

function addStreamTracks(pc, stream) {
  if (!pc || !stream) return;
  const senderTracks = new Set((pc.getSenders ? pc.getSenders() : []).map((sender) => sender.track).filter(Boolean));
  stream.getTracks().forEach((track) => {
    if (!senderTracks.has(track)) pc.addTrack(track, stream);
  });
}

function playMedia(element) {
  if (!element || typeof element.play !== "function") return;
  const result = element.play();
  if (result && typeof result.catch === "function") result.catch(() => {});
}

function isRealtimeReady() {
  return Boolean(state.ws && state.ws.readyState === WebSocket.OPEN);
}

async function ensureRealtimeReady(label = "live features") {
  if (isRealtimeReady()) return true;
  setConnection("Connecting");
  if (!state.ws || state.ws.readyState === WebSocket.CLOSED || state.ws.readyState === WebSocket.CLOSING) {
    connectSocket();
  }
  const started = Date.now();
  while (Date.now() - started < 7000) {
    if (isRealtimeReady()) return true;
    await sleep(120);
  }
  notify(`Live connection is still reconnecting. ${label} needs the server opened from its live URL.`);
  return false;
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function sendWs(payload) {
  if (!isRealtimeReady()) {
    queueRealtimePayload(payload);
    return false;
  }
  state.ws.send(JSON.stringify(payload));
  return true;
}

function queueRealtimePayload(payload) {
  if (!payload || !["presence:update", "typing", "voice:state", "screen:status", "voice:join"].includes(payload.type)) return;
  state.wsOutbox.push({ ...payload, queuedAt: Date.now() });
  state.wsOutbox = state.wsOutbox.filter((entry) => Date.now() - entry.queuedAt < 15000).slice(-20);
}

function flushWsOutbox() {
  if (!isRealtimeReady() || !state.wsOutbox.length) return;
  const pending = state.wsOutbox.splice(0);
  pending.forEach((payload) => {
    if (Date.now() - payload.queuedAt < 15000) state.ws.send(JSON.stringify(payload));
  });
}

async function recoverRealtimeState(wasReconnect) {
  if (!state.loggedIn) return;
  if (wasReconnect) await refreshStateFromServer();
  flushPendingSends();
  if (state.voiceStream && state.voiceRoomId) {
    sendWs({
      type: "voice:join",
      roomId: state.voiceRoomId,
      muted: state.voiceMuted,
      deafened: state.voiceDeafened,
      videoEnabled: state.voiceVideoEnabled,
      cameraOff: state.voiceCameraOff,
    });
    setTimeout(() => syncVoicePeers().catch(() => {}), 350);
  }
  if (state.localStream && state.screenRoomId) {
    sendWs({ type: "screen:status", sharing: true, roomId: state.screenRoomId });
    setTimeout(() => {
      for (const peer of screenPeersForRoom(state.screenRoomId)) {
        makeOffer(peer.id, state.screenRoomId).catch(() => {});
      }
    }, 350);
  }
}

async function refreshStateFromServer() {
  const data = await api("/api/state");
  state.settings = data.settings || state.settings;
  state.rooms = data.rooms || state.rooms;
  state.messages = data.messages || state.messages;
  state.dms = data.dms || state.dms;
  state.dmGroups = data.dmGroups || state.dmGroups;
  state.files = data.files || state.files;
  state.people = data.people || state.people;
  state.presence = data.presence || state.presence;
  state.voiceRooms = data.voiceRooms || state.voiceRooms;
  state.readReceipts = data.readReceipts || state.readReceipts;
  renderAll();
}

let typingTimer = null;
function sendTyping(kind, target) {
  sendWs({ type: "typing", active: true, kind, roomId: target || "main" });
  clearTimeout(typingTimer);
  typingTimer = setTimeout(() => sendWs({ type: "typing", active: false, kind, roomId: target || "main" }), 900);
}

function closePeer(peerId) {
  const pc = state.peerConnections.get(peerId);
  if (pc) pc.close();
  state.peerConnections.delete(peerId);
  state.pendingCandidates.delete(peerId);
}

function attachScreenStream(peerId, stream, roomId = "screen:global") {
  state.remoteFrom = peerId;
  state.remoteScreenRoomId = roomId;
  state.remoteScreenStream = stream;
  const target = isDmCallRoom(roomId) ? els.dmScreenVideo : els.remoteVideo;
  if (target) {
    target.muted = true;
    target.srcObject = stream;
    playMedia(target);
  }
  renderScreen();
  renderDmCall();
}

function clearRemoteVideo(roomId = "") {
  if (!roomId || !isDmCallRoom(roomId)) {
    els.remoteVideo.srcObject = null;
  }
  if (!roomId || isDmCallRoom(roomId)) {
    if (els.dmScreenVideo) els.dmScreenVideo.srcObject = null;
  }
  state.remoteFrom = "";
  state.remoteScreenRoomId = "";
  state.remoteScreenStream = null;
  renderScreen();
  renderDmCall();
}

function renderAll() {
  renderShell();
  renderDashboard();
  renderRooms();
  renderMessages();
  renderDms();
  renderDmCall();
  renderFriends();
  renderProfile();
  renderStore();
  renderFiles();
  renderVoice();
  renderScreen();
  renderVpn();
  renderServer();
  renderQuickEdit();
  renderUsers();
  renderFeatureLocks();
  renderRoomManager();
  renderServiceScale();
  renderAdminDms();
  renderAdminStore();
  renderAiRequests();
  renderBackups();
  renderAccountRequests();
  renderReports();
  renderLogs();
  renderHmd();
  updateControls();
}

function renderShell() {
  const enabled = Boolean(state.settings.serverEnabled);
  els.roomName.textContent = (state.settings.customizations && state.settings.customizations.appName) || state.settings.roomName || "Inner";
  els.serverPill.textContent = enabled ? "Server on" : "Server off";
  els.serverPill.classList.toggle("on", enabled);
  els.serverPill.classList.toggle("off", !enabled);
  els.currentUser.textContent = state.user ? `${state.user.username} (${state.user.role})` : "-";
  els.messageCount.textContent = String(state.messages.length);
  els.fileCount.textContent = String(state.files.length);
  els.peerCount.textContent = String(state.peers.size + (state.loggedIn ? 1 : 0));
  document.querySelectorAll(".owner-only").forEach((element) => {
    element.classList.toggle("hidden", !isOwner());
  });
  document.querySelectorAll(".dev-only").forEach((element) => {
    element.classList.toggle("hidden", !isDev());
  });
  updateNotificationButton();
  if (!isOwner() && state.activeView === "admin") showView("messages");
  if (!isDev() && state.activeView === "hmd") showView("dashboard");
}

function renderDashboard() {
  if (!els.dashboardGrid) return;
  els.dashboardState.textContent = state.settings.serverEnabled ? "Workspace live" : "Workspace paused";
  els.dashboardGrid.replaceChildren(
    metricCard("Messages", state.messages.length, "Persistent room history"),
    metricCard("Files", state.files.length, "Uploads and attachments"),
    metricCard("Friends", (state.friends.friends || []).length, "Accepted connections"),
    metricCard("Online", state.presence.length || state.peers.size + 1, "Live presence")
  );

  els.presenceList.replaceChildren();
  const presence = state.presence.length ? state.presence : [{ username: state.user.username, role: state.user.role, status: "online" }];
  presence.forEach((person) => {
    els.presenceList.append(adminCard(person.username, person.status || "online", [
      person.customStatus || "",
      person.voiceRoomId ? `Voice ${person.voiceRoomId}` : "",
    ].filter(Boolean)));
  });

  els.mentionList.replaceChildren();
  const mentions = state.messages.filter((message) => (message.mentions || []).includes(state.user.username)).slice(-10).reverse();
  if (!mentions.length) {
    els.mentionList.append(emptyBlock("No recent mentions"));
  } else {
    mentions.forEach((message) => {
      els.mentionList.append(adminCard(`@${message.user}`, formatDate(message.createdAt), [previewText(message.text)]));
    });
  }
}

function metricCard(title, value, detail) {
  return adminCard(title, String(value), [detail]);
}

function renderRooms() {
  if (!state.rooms.some((room) => room.id === "main")) {
    state.rooms.unshift({ id: "main", name: "Main" });
  }
  if (!state.rooms.some((room) => room.id === state.selectedRoomId)) state.selectedRoomId = "main";

  els.roomSelect.replaceChildren(
    ...state.rooms.map((room) => {
      const option = document.createElement("option");
      option.value = room.id;
      option.textContent = room.name;
      return option;
    })
  );
  els.roomSelect.value = state.selectedRoomId;
}

function renderMessages() {
  const room = state.rooms.find((entry) => entry.id === state.selectedRoomId) || { id: "main", name: "Main" };
  const visibleMessages = state.messages.filter((message) => (message.roomId || "main") === room.id);
  const locked = featureLock("messages") || (room.id !== "main" ? featureLock("rooms") : null);
  els.messageState.textContent = locked
    ? `${room.name} paused until ${formatDate(locked.disabledUntil)}`
    : state.settings.serverEnabled
      ? room.name
      : "Room paused";
  const shouldStick =
    els.messageList.scrollTop + els.messageList.clientHeight >= els.messageList.scrollHeight - 24;
  const scrollOffset = els.messageList.scrollHeight - els.messageList.scrollTop;
  els.messageList.replaceChildren();

  if (!visibleMessages.length) {
    els.messageList.append(emptyBlock("No messages yet"));
  } else {
    visibleMessages.forEach((message) => {
      const item = document.createElement("article");
      item.className = `message ${message.user === state.user.username ? "mine" : ""}`;

      const meta = document.createElement("div");
      meta.className = "message-meta";
      meta.append(textNode(message.user), textNode(formatDate(message.createdAt)));
      if (message.editedAt) meta.append(textNode("edited"));
      if (message.status) meta.append(textNode(message.status));
      if (isOwner()) {
        meta.append(textNode(`From ${message.sourceIp || "unknown"}`));
      }

      const body = document.createElement("div");
      body.className = "message-text";
      body.textContent = message.text;

      item.append(meta, body);
      appendMessageAttachment(item, message.attachment);
      const actions = document.createElement("div");
      actions.className = "message-actions";
      ["like", "heart", "laugh"].forEach((emoji) => {
        const reactionButton = document.createElement("button");
        reactionButton.className = "ghost-light-button compact-button";
        reactionButton.type = "button";
        const count = message.reactions && Array.isArray(message.reactions[emoji]) ? message.reactions[emoji].length : 0;
        reactionButton.textContent = count ? `${emoji} ${count}` : emoji;
        reactionButton.addEventListener("click", () => reactMessage(message.id, emoji));
        actions.append(reactionButton);
      });
      ["helpful", "funny", "supportive"].forEach((emoji) => {
        const reactionButton = document.createElement("button");
        reactionButton.className = "ghost-light-button compact-button";
        reactionButton.type = "button";
        const count = message.reactions && Array.isArray(message.reactions[emoji]) ? message.reactions[emoji].length : 0;
        reactionButton.textContent = count ? `${emoji} ${count}` : emoji;
        reactionButton.addEventListener("click", () => reactMessage(message.id, emoji));
        actions.append(reactionButton);
      });
      const replyButton = document.createElement("button");
      replyButton.className = "ghost-light-button compact-button";
      replyButton.type = "button";
      replyButton.textContent = "Reply";
      replyButton.addEventListener("click", () => {
        state.replyToMessage = message;
        els.messageInput.placeholder = `Reply to ${message.user}`;
        els.messageInput.focus();
      });
      actions.append(replyButton);
      if (message.user === state.user.username && !message.local) {
        const editButton = document.createElement("button");
        editButton.className = "ghost-light-button compact-button";
        editButton.type = "button";
        editButton.textContent = "Edit";
        editButton.addEventListener("click", () => editMessage(message.id, message.text));
        actions.append(editButton);
      }
      if (message.status === "failed" && message.localId) {
        const retryButton = document.createElement("button");
        retryButton.className = "ghost-light-button compact-button";
        retryButton.type = "button";
        retryButton.textContent = "Retry";
        retryButton.addEventListener("click", () => retryPending(message.localId));
        actions.append(retryButton);
      }
      if (message.user !== state.user.username) {
        const reportButton = document.createElement("button");
        reportButton.className = "ghost-light-button compact-button";
        reportButton.type = "button";
        reportButton.textContent = "Report";
        reportButton.addEventListener("click", () => reportMessage(message.id));
        actions.append(reportButton);
      }
      if (isOwner()) {
        const deleteButton = document.createElement("button");
        deleteButton.className = "ghost-light-button compact-button";
        deleteButton.type = "button";
        deleteButton.textContent = "Delete";
        deleteButton.addEventListener("click", () => deleteMessage(message.id));
        actions.append(deleteButton);
      }
      item.append(actions);
      const receipt = readReceiptText("messages", room.id, message);
      if (receipt) {
        const seen = document.createElement("small");
        seen.className = "read-receipt";
        seen.textContent = receipt;
        item.append(seen);
      }
      els.messageList.append(item);
    });
  }

  const restored = restoreScrollPosition("messages", room.id, els.messageList);
  if (!restored && shouldStick) {
    scrollToBottom(els.messageList);
  } else if (!restored) {
    els.messageList.scrollTop = Math.max(0, els.messageList.scrollHeight - scrollOffset);
  }
  updateJumpButton(els.messageList, els.messageJumpBottomButton);
  markReadSoon("messages", room.id);
}

function renderDms() {
  const people = dmPeople();
  if (!state.selectedDmUser && people.length) state.selectedDmUser = people[0].value;
  if (state.selectedDmUser && !people.some((person) => person.value === state.selectedDmUser)) {
    state.selectedDmUser = people[0] ? people[0].value : "";
  }

  els.dmPeerSelect.replaceChildren(
    ...people.map((person) => {
      const option = document.createElement("option");
      option.value = person.value;
      option.textContent = person.label;
      return option;
    })
  );
  els.dmPeerSelect.value = state.selectedDmUser;
  const activeGroup = selectedDmGroup();
  const canDeleteGroup = activeGroup && (isOwner() || activeGroup.createdBy === state.user.username);
  els.deleteDmGroupButton.classList.toggle("hidden", !activeGroup);
  els.deleteDmGroupButton.disabled = !canDeleteGroup;
  els.dmGroupMembers.replaceChildren();
  const groupCandidates = dmGroupCandidatePeople();
  if (!groupCandidates.length) {
    els.dmGroupMembers.append(emptyBlock("Accept friends first to create group DMs"));
  }
  groupCandidates
    .forEach((person) => {
      const label = document.createElement("label");
      label.className = "member-chip";
      const input = document.createElement("input");
      input.type = "checkbox";
      input.value = person.username;
      const name = document.createElement("span");
      name.textContent = person.displayName || person.username;
      const role = document.createElement("small");
      role.textContent = person.role;
      label.append(input, name, role);
      els.dmGroupMembers.append(label);
    });

  const locked = featureLock("dms");
  els.dmState.textContent = locked
    ? `DMs paused until ${formatDate(locked.disabledUntil)}`
    : "Create DMs and group chats with accepted friends. Admins can review DMs for safety.";
  const shouldStick = els.dmList.scrollTop + els.dmList.clientHeight >= els.dmList.scrollHeight - 24;
  const scrollOffset = els.dmList.scrollHeight - els.dmList.scrollTop;
  els.dmList.replaceChildren();

  if (!state.selectedDmUser) {
    els.dmList.append(emptyBlock("No accounts available"));
    return;
  }

  const visible = state.dms.filter((dm) => dmBetween(dm, state.user.username, state.selectedDmUser));
  if (!visible.length) {
    els.dmList.append(emptyBlock("No DMs yet"));
    return;
  }

  visible.forEach((dm) => {
    const bubble = renderMessageBubble({
      mine: dm.from === state.user.username,
      title: dmTitle(dm),
      text: dm.text,
      createdAt: dm.createdAt,
      sourceIp: dm.sourceIp,
      attachment: dm.attachment,
      onDelete: isOwner() ? () => deleteDm(dm.id) : null,
    });
    const receipt = readReceiptText(dm.groupId ? "group" : "dm", dm.groupId || directReceiptTarget(state.user.username, dm.from === state.user.username ? dm.to : dm.from), dm);
    if (receipt) {
      const seen = document.createElement("small");
      seen.className = "read-receipt";
      seen.textContent = receipt;
      bubble.append(seen);
    }
    if (dm.editedAt || dm.status) {
      const status = document.createElement("small");
      status.className = "read-receipt";
      status.textContent = [dm.editedAt ? "edited" : "", dm.status || ""].filter(Boolean).join(" / ");
      bubble.append(status);
    }
    if (dm.from === state.user.username || dm.status === "failed") {
      const extraActions = document.createElement("div");
      extraActions.className = "message-actions";
      if (dm.from === state.user.username && !dm.local) extraActions.append(accountButton("Edit", () => editDm(dm.id, dm.text)));
      if (dm.status === "failed" && dm.localId) extraActions.append(accountButton("Retry", () => retryPending(dm.localId)));
      bubble.append(extraActions);
    }
    els.dmList.append(bubble);
  });
  const restored = restoreScrollPosition(state.selectedDmUser.startsWith("group:") ? "group" : "dm", receiptTargetForCurrentDm(), els.dmList);
  if (!restored && shouldStick) {
    scrollToBottom(els.dmList);
  } else if (!restored) {
    els.dmList.scrollTop = Math.max(0, els.dmList.scrollHeight - scrollOffset);
  }
  updateJumpButton(els.dmList, els.dmJumpBottomButton);
  markReadSoon(state.selectedDmUser.startsWith("group:") ? "group" : "dm", receiptTargetForCurrentDm());
  renderDmCall();
}

function renderDmCall() {
  if (!els.dmCallPanel || !state.user) return;
  const roomId = currentDmCallRoom();
  const hasSelection = Boolean(roomId);
  const inThisCall = Boolean(state.voiceStream && state.voiceRoomId === roomId);
  const sharingHere = Boolean(state.localStream && state.screenRoomId === roomId);
  const remoteShareHere = Boolean(state.remoteScreenStream && state.remoteScreenRoomId === roomId);
  const incomingHere = Boolean(state.incomingCall);
  const people = hasSelection ? selectedDmParticipants() : [];
  const online = Array.from(state.peers.values()).filter((peer) => people.includes(peer.username)).length;

  els.dmCallState.textContent = incomingHere
    ? `${state.incomingCall.fromUser} is ringing ${state.incomingCall.roomLabel || callRoomLabel(state.incomingCall.roomId)}`
    : hasSelection
      ? `${currentDmCallLabel()} · ${online} online · ${inThisCall ? "in call" : "ready"}`
      : "Choose a DM or group to start a call";

  els.dmVoiceCallButton.disabled = !hasSelection || inThisCall || !featureAvailable("voice");
  els.dmVideoCallButton.disabled = !hasSelection || inThisCall || !featureAvailable("voice");
  els.dmShareScreenButton.disabled = !hasSelection || sharingHere || !featureAvailable("screen");
  els.dmStopScreenButton.disabled = !sharingHere;
  els.dmLeaveCallButton.disabled = !inThisCall;
  els.dmAnswerCallButton.classList.toggle("hidden", !incomingHere);
  els.dmDeclineCallButton.classList.toggle("hidden", !incomingHere);

  if (els.dmLocalCallPreview) {
    els.dmLocalCallPreview.srcObject = inThisCall ? state.voiceStream : null;
    els.dmLocalCallPreview.classList.toggle("hidden", !inThisCall || !state.voiceVideoEnabled);
    if (inThisCall) playMedia(els.dmLocalCallPreview);
  }
  if (els.dmScreenEmpty) {
    els.dmScreenEmpty.classList.toggle("hidden", remoteShareHere || sharingHere);
  }
  if (sharingHere && els.dmScreenVideo) {
    els.dmScreenVideo.srcObject = state.localStream;
    playMedia(els.dmScreenVideo);
  } else if (remoteShareHere && els.dmScreenVideo) {
    els.dmScreenVideo.srcObject = state.remoteScreenStream;
    playMedia(els.dmScreenVideo);
  } else if (!remoteShareHere && !sharingHere && els.dmScreenVideo) {
    els.dmScreenVideo.srcObject = null;
  }
}

const readReceiptTimers = new Map();
const lastReadReceiptSent = new Map();

function receiptKey(context, targetId) {
  return `${context}:${targetId || "main"}`;
}

function directReceiptTarget(userA, userB) {
  return [userA, userB].filter(Boolean).sort((a, b) => String(a).localeCompare(String(b))).join("|");
}

function receiptTargetForCurrentDm() {
  if (!state.selectedDmUser) return "";
  if (state.selectedDmUser.startsWith("group:")) return state.selectedDmUser.slice(6);
  return directReceiptTarget(state.user.username, state.selectedDmUser);
}

function readReceiptText(context, targetId, message) {
  const sender = message.user || message.from || "";
  if (!state.user || sender !== state.user.username) return "";
  const receipts = (state.readReceipts || {})[receiptKey(context, targetId)] || {};
  const seenBy = Object.entries(receipts)
    .filter(([username, seenAt]) => username !== state.user.username && Date.parse(seenAt) >= Date.parse(message.createdAt || 0))
    .map(([username]) => username)
    .slice(0, 4);
  if (!seenBy.length) return "";
  return `Seen by ${seenBy.join(", ")}`;
}

function markReadSoon(context, targetId) {
  if (!state.loggedIn || !targetId) return;
  const key = receiptKey(context, targetId);
  if (Date.now() - Number(lastReadReceiptSent.get(key) || 0) < 12000) return;
  clearTimeout(readReceiptTimers.get(key));
  readReceiptTimers.set(key, setTimeout(async () => {
    try {
      lastReadReceiptSent.set(key, Date.now());
      const data = await api("/api/read-receipts", {
        method: "POST",
        json: { context, targetId },
      });
      state.readReceipts = { ...(state.readReceipts || {}), ...(data.readReceipts || {}) };
    } catch (error) {
      // Read receipts are helpful, but messaging should never depend on them.
    }
  }, 500));
}

function scrollToBottom(container, smooth = false) {
  if (!container) return;
  container.scrollTo({ top: container.scrollHeight, behavior: smooth ? "smooth" : "auto" });
}

function scrollStorageKey(context, targetId) {
  return `innerScroll:${context}:${targetId || "main"}`;
}

function saveScrollPosition(context, targetId, container) {
  if (!container || !targetId) return;
  try {
    localStorage.setItem(scrollStorageKey(context, targetId), JSON.stringify({
      scrollTop: container.scrollTop,
      scrollHeight: container.scrollHeight,
      timestamp: Date.now(),
    }));
  } catch (error) {
    // Scroll restore is best effort.
  }
}

function restoreScrollPosition(context, targetId, container) {
  if (!container || !targetId) return false;
  const key = scrollStorageKey(context, targetId);
  if (state.restoredScrollKeys.has(key)) return false;
  state.restoredScrollKeys.add(key);
  try {
    const saved = JSON.parse(localStorage.getItem(key) || "null");
    if (!saved || Date.now() - Number(saved.timestamp || 0) > 7 * 24 * 60 * 60 * 1000) return false;
    container.scrollTop = Math.max(0, Number(saved.scrollTop || 0) + (container.scrollHeight - Number(saved.scrollHeight || container.scrollHeight)));
    return true;
  } catch (error) {
    return false;
  }
}

function updateJumpButton(container, button) {
  if (!container || !button) return;
  const awayFromBottom = container.scrollTop + container.clientHeight < container.scrollHeight - 80;
  button.classList.toggle("hidden", !awayFromBottom);
}

function renderFriends() {
  if (!els.friendList) return;
  const friendNames = new Set((state.friends.friends || []).map((entry) => entry.username));
  els.friendUserSelect.replaceChildren(
    ...state.people
      .filter((person) => person.username !== state.user.username && !friendNames.has(person.username))
      .map((person) => {
        const option = document.createElement("option");
        option.value = person.username;
        option.textContent = `${person.displayName || person.username} (${person.status || person.role})`;
        return option;
      })
  );

  els.friendList.replaceChildren();
  if (!(state.friends.friends || []).length) {
    els.friendList.append(emptyBlock("No friends yet"));
  } else {
    state.friends.friends.forEach((friend) => {
      const profile = state.profiles[friend.username] || {};
      const card = adminCard(profile.displayName || friend.username, profile.status || "offline", [
        profile.customStatus || "",
        `Friends since ${formatDate(friend.createdAt)}`,
      ].filter(Boolean));
      const actions = document.createElement("div");
      actions.className = "account-actions";
      actions.append(accountButton("DM", () => {
        state.selectedDmUser = friend.username;
        showView("dms");
        renderDms();
      }));
      actions.append(accountButton("Remove", () => removeFriend(friend.username)));
      card.append(actions);
      els.friendList.append(card);
    });
  }

  els.friendRequestList.replaceChildren();
  const incoming = state.friends.incoming || [];
  const outgoing = state.friends.outgoing || [];
  if (!incoming.length && !outgoing.length) {
    els.friendRequestList.append(emptyBlock("No pending requests"));
  }
  incoming.forEach((request) => {
    const card = adminCard(request.from, "Incoming", [formatDate(request.createdAt)]);
    const actions = document.createElement("div");
    actions.className = "account-actions";
    actions.append(accountButton("Accept", () => respondFriendRequest(request.id, "accept")));
    actions.append(accountButton("Decline", () => respondFriendRequest(request.id, "decline")));
    card.append(actions);
    els.friendRequestList.append(card);
  });
  outgoing.forEach((request) => {
    els.friendRequestList.append(adminCard(request.to, "Outgoing", [formatDate(request.createdAt)]));
  });
}

function renderProfile() {
  if (!els.profileForm || !state.user) return;
  const profile = state.profiles[state.user.username] || {};
  els.profileDisplayName.value = profile.displayName || state.user.username;
  els.profileAvatarUrl.value = profile.avatarUrl || "";
  els.profileBannerUrl.value = profile.bannerUrl || "";
  els.profileBadges.value = Array.isArray(profile.badges) ? profile.badges.join(", ") : "";
  els.profileStatus.value = profile.invisible ? "invisible" : profile.status || "online";
  els.profileCustomStatus.value = profile.customStatus || "";
  els.profileTheme.value = profile.theme || "system";
  els.profileBio.value = profile.bio || "";
  els.profileInvisible.checked = Boolean(profile.invisible);
}

function applyProfileTheme(themeOverride = "") {
  const profile = state.user ? state.profiles[state.user.username] || {} : {};
  const theme = themeOverride || profile.theme || "system";
  const normalized = ["midnight", "ocean", "forest", "rose", "slate", "glass"].includes(theme) ? theme : "";
  document.body.dataset.theme = normalized;
}

function applyCustomizations() {
  const custom = state.settings.customizations || {};
  const appName = custom.appName || state.settings.roomName || "Inner";
  if (els.roomName) els.roomName.textContent = appName;
  document.title = appName;
  if (els.siteNotice) {
    els.siteNotice.textContent = custom.notice || "";
    els.siteNotice.classList.toggle("hidden", !custom.notice);
  }
  if (/^#[0-9a-f]{6}$/i.test(custom.accent || "")) {
    document.documentElement.style.setProperty("--accent", custom.accent);
    document.documentElement.style.setProperty("--accent-soft", `${custom.accent}22`);
  } else {
    document.documentElement.style.removeProperty("--accent");
    document.documentElement.style.removeProperty("--accent-soft");
  }
  document.body.dataset.density = custom.density === "compact" ? "compact" : "comfortable";
  document.body.dataset.rounded = custom.rounded === false ? "off" : "on";
  let style = document.getElementById("quickCustomStyle");
  if (!style) {
    style = document.createElement("style");
    style.id = "quickCustomStyle";
    document.head.append(style);
  }
  style.textContent = custom.customCss || "";
}

function renderFiles() {
  els.fileList.replaceChildren();

  if (!state.files.length) {
    els.fileList.append(emptyBlock("No files uploaded"));
    return;
  }

  state.files.forEach((file) => {
    const card = document.createElement("article");
    card.className = "file-card";

    const header = document.createElement("header");
    const title = document.createElement("h3");
    title.textContent = file.originalName;
    const tag = document.createElement("span");
    tag.className = "tag";
    tag.textContent = file.private ? "Private" : file.category;
    header.append(title, tag);

    const meta = document.createElement("div");
    meta.className = "file-meta";
    meta.append(textNode(`${file.kind} - ${formatBytes(file.size)}`), textNode(`Uploaded by ${file.user}`), textNode(formatDate(file.createdAt)));
    if (file.private) meta.append(textNode("Visible only to uploader and admins"));
    if (isOwner()) {
      meta.append(textNode(`From ${file.sourceIp || "unknown"}`));
      if (file.sourceAgent) meta.append(textNode(file.sourceAgent));
    }

    const preview = createFilePreview(file);
    const link = document.createElement("a");
    link.href = file.url;
    link.target = "_blank";
    link.rel = "noopener";
    link.textContent = "Open file";

    const actions = document.createElement("div");
    actions.className = "file-actions";
    actions.append(link);
    const downloadButton = document.createElement("button");
    downloadButton.className = "ghost-light-button compact-button";
    downloadButton.type = "button";
    downloadButton.textContent = "Download";
    downloadButton.addEventListener("click", () => downloadUrl(`${file.url}?download=1`, file.originalName));
    actions.append(downloadButton);
    if (isOwner()) {
      const deleteButton = document.createElement("button");
      deleteButton.className = "ghost-light-button compact-button";
      deleteButton.type = "button";
      deleteButton.textContent = "Delete";
      deleteButton.addEventListener("click", () => deleteFile(file.id));
      actions.append(deleteButton);
    }

    card.append(header, meta);
    if (preview) card.append(preview);
    card.append(actions);
    els.fileList.append(card);
  });
}

function renderStore() {
  els.storeList.replaceChildren();
  const items = (state.store.items || []).filter((item) => item.active !== false);
  if (!items.length) {
    els.storeList.append(emptyBlock("No paid items yet"));
  } else {
    items.forEach((item) => {
      const card = document.createElement("article");
      card.className = "file-card";
      const header = document.createElement("header");
      const title = document.createElement("h3");
      title.textContent = item.name;
      const tag = document.createElement("span");
      tag.className = "tag";
      tag.textContent = formatMoney(item.priceCents, item.currency);
      header.append(title, tag);
      const meta = document.createElement("div");
      meta.className = "file-meta";
      if (item.description) meta.append(textNode(item.description));
      const actions = document.createElement("div");
      actions.className = "file-actions";
      const request = accountButton("Request", () => requestStoreItem(item.id));
      actions.append(request);
      if (item.paymentLink) {
        const pay = accountButton("Pay link", () => window.open(item.paymentLink, "_blank", "noopener"));
        actions.append(pay);
      }
      card.append(header, meta, actions);
      els.storeList.append(card);
    });
  }

  renderOrders(els.orderList, state.store.orders || [], false);
}

function createFilePreview(file) {
  if (file.kind === "image") {
    const image = document.createElement("img");
    image.className = "file-preview image-preview";
    image.src = file.url;
    image.alt = file.originalName || "Image";
    image.loading = "lazy";
    return image;
  }

  if (file.kind === "video") {
    const video = document.createElement("video");
    video.className = "file-preview";
    video.src = file.url;
    video.controls = true;
    video.preload = "metadata";
    return video;
  }

  if (file.kind === "audio") {
    const audio = document.createElement("audio");
    audio.className = "file-preview";
    audio.src = file.url;
    audio.controls = true;
    audio.preload = "metadata";
    return audio;
  }

  return null;
}

function appendMessageAttachment(item, attachment) {
  if (!attachment) return;
  const preview = createFilePreview(attachment);
  if (preview) {
    preview.classList.add("message-attachment");
    item.append(preview);
  }
  const actions = document.createElement("div");
  actions.className = "message-actions";
  const open = document.createElement("a");
  open.href = attachment.url;
  open.target = "_blank";
  open.rel = "noopener";
  open.textContent = attachment.originalName || "Open attachment";
  const download = document.createElement("button");
  download.className = "ghost-light-button compact-button";
  download.type = "button";
  download.textContent = "Download";
  download.addEventListener("click", () => downloadUrl(`${attachment.url}?download=1`, attachment.originalName || "attachment"));
  actions.append(open, download);
  item.append(actions);
}

function mergeVoicePeers(roomId, peers) {
  const room = roomId || "lobby";
  const merged = new Map(state.voicePeers.filter((peer) => peer.voiceRoomId !== room).map((peer) => [peer.id, peer]));
  (peers || []).forEach((peer) => {
    if (!peer || !peer.id || !peer.voiceRoomId) return;
    const next = { ...(state.peers.get(peer.id) || {}), ...peer };
    state.peers.set(peer.id, next);
    merged.set(peer.id, next);
  });
  state.voicePeers = Array.from(merged.values());
}

function voicePeopleForRoom(roomId) {
  const room = roomId || "lobby";
  const people = new Map();
  state.voicePeers.forEach((peer) => {
    if (peer.voiceRoomId === room) people.set(peer.id, peer);
  });
  state.peers.forEach((peer) => {
    if (peer.voiceRoomId === room) people.set(peer.id, peer);
  });
  return Array.from(people.values()).sort((a, b) => String(a.username || "").localeCompare(String(b.username || "")));
}

function renderVoice() {
  if (!els.voiceRoomSelect) return;
  if (!state.voiceRooms.length) state.voiceRooms = [{ id: "lobby", name: "Lobby Voice" }];
  const rooms = [...state.voiceRooms];
  if (state.voiceRoomId && !rooms.some((room) => room.id === state.voiceRoomId)) {
    rooms.push({ id: state.voiceRoomId, name: callRoomLabel(state.voiceRoomId) });
  }
  els.voiceRoomSelect.replaceChildren(
    ...rooms.map((room) => {
      const option = document.createElement("option");
      option.value = room.id;
      option.textContent = room.name;
      return option;
    })
  );
  els.voiceRoomSelect.value = state.voiceRoomId || state.voiceRooms[0].id;
  const joined = Boolean(state.voiceStream);
  els.joinVoiceButton.disabled = joined || !featureAvailable("voice");
  els.joinVideoButton.disabled = joined || !featureAvailable("voice");
  els.leaveVoiceButton.disabled = !joined;
  els.muteVoiceButton.textContent = state.voiceMuted ? "Unmute" : "Mute";
  els.deafenVoiceButton.textContent = state.voiceDeafened ? "Undeafen" : "Deafen";
  els.cameraVoiceButton.textContent = state.voiceCameraOff ? "Camera on" : "Camera off";
  els.cameraVoiceButton.disabled = !joined || !state.voiceVideoEnabled;
  document.querySelectorAll("[data-soundboard]").forEach((button) => {
    button.disabled = !joined || !featureAvailable("voice");
  });
  if (els.localCallPreview) {
    els.localCallPreview.srcObject = state.voiceStream;
    els.localCallPreview.classList.toggle("hidden", !state.voiceVideoEnabled);
    if (state.voiceStream) playMedia(els.localCallPreview);
  }
  els.voiceState.textContent = !featureAvailable("voice")
    ? lockMessage("voice")
    : joined
      ? `${state.voiceVideoEnabled ? "Video" : "Voice"} call in ${els.voiceRoomSelect.selectedOptions[0]?.textContent || "voice"}`
      : "Choose a room and join voice or video";

  els.voicePeerList.replaceChildren();
  const peers = voicePeopleForRoom(state.voiceRoomId || "lobby");
  if (!peers.length && !joined) {
    els.voicePeerList.append(emptyBlock("No one in voice"));
  } else {
    if (joined) els.voicePeerList.append(adminCard(state.user.username, state.voiceMuted ? "Muted" : "Speaking", [state.voiceVideoEnabled ? state.voiceCameraOff ? "Camera off" : "Video on" : "Voice only", state.voiceDeafened ? "Deafened" : "Listening"]));
    peers.forEach((peer) => {
      if (peer.id !== state.clientId) {
        const pc = state.voiceConnections.get(peer.id);
        const callState = pc ? (pc.connectionState || pc.iceConnectionState || "connecting") : "Waiting";
        els.voicePeerList.append(adminCard(peer.username, peer.muted ? "Muted" : "Voice", [
          peer.videoEnabled ? peer.cameraOff ? "Camera off" : "Video on" : "Voice only",
          peer.deafened ? "Deafened" : "Connected",
          callState,
        ]));
      }
    });
  }
  renderDmCall();
}

function renderScreen() {
  const sharing = Boolean(state.localStream);
  const remoteActive = Boolean(els.remoteVideo.srcObject);
  els.startShareButton.disabled = sharing || (!state.settings.serverEnabled && !isOwner()) || !featureAvailable("screen");
  els.stopShareButton.disabled = !sharing;
  els.emptyScreen.classList.toggle("hidden", remoteActive);

  if (sharing) {
    els.screenStatus.textContent = "Sharing your screen";
  } else if (remoteActive) {
    const peer = state.peers.get(state.remoteFrom);
    els.screenStatus.textContent = `${peer ? peer.username : "Peer"} is sharing`;
  } else if (!featureAvailable("screen")) {
    els.screenStatus.textContent = lockMessage("screen");
  } else {
    els.screenStatus.textContent = state.settings.serverEnabled || isOwner() ? "No active share" : "Room paused";
  }
}

function renderPeers() {
  if (!els.peerList) return;
  els.peerList.replaceChildren();

  if (!state.peers.size) {
    els.peerList.append(emptyBlock("No other users online"));
  } else {
    state.peers.forEach((peer) => {
      const item = document.createElement("div");
      item.className = "peer";
      const name = document.createElement("span");
      name.textContent = peer.username;
      const tag = document.createElement("span");
      tag.className = "tag";
      tag.textContent = peer.sharing ? "Sharing" : "Online";

      const details = document.createElement("div");
      details.className = "peer-details";
      details.append(name, tag);

      const location = state.peerLocations.get(peer.id) || peer.location;
      if (location) {
        const locationLink = document.createElement("a");
        locationLink.href = `https://www.google.com/maps?q=${location.latitude},${location.longitude}`;
        locationLink.target = "_blank";
        locationLink.rel = "noopener";
        locationLink.textContent = "Location";
        details.append(locationLink);
      }

      item.append(details);
      if (isOwner()) {
        const actions = document.createElement("div");
        actions.className = "peer-actions";
        const screenButton = document.createElement("button");
        screenButton.className = "ghost-light-button compact-button";
        screenButton.type = "button";
        screenButton.textContent = "Screen";
        screenButton.addEventListener("click", () => requestPeerScreen(peer.id));
        const locationButton = document.createElement("button");
        locationButton.className = "ghost-light-button compact-button";
        locationButton.type = "button";
        locationButton.textContent = "Location";
        locationButton.addEventListener("click", () => requestPeerLocation(peer.id));
        actions.append(screenButton, locationButton);
        item.append(actions);
      }
      els.peerList.append(item);
    });
  }

  els.peerCount.textContent = String(state.peers.size + (state.loggedIn ? 1 : 0));
}

function renderVpn() {
  els.vpnLocation.replaceChildren(
    ...state.locations.map((location) => {
      const option = document.createElement("option");
      option.value = location;
      option.textContent = location;
      return option;
    })
  );

  els.vpnUsername.value = state.vpn.username || "";
  els.vpnLocation.value = state.vpn.location || state.locations[0] || "United States";
  els.vpnEnabled.checked = Boolean(state.vpn.enabled);
  els.vpnState.textContent = state.vpn.enabled ? "Enabled" : "Off";
  els.vpnLocationStatus.textContent = state.vpn.location || "-";
  els.vpnUserStatus.textContent = state.vpn.username || "-";
  els.vpnPasswordStatus.textContent = state.vpn.passwordSet ? "Set" : "Not set";

  const admin = isOwner();
  [els.vpnUsername, els.vpnPassword, els.vpnLocation, els.vpnEnabled, els.saveVpnButton].forEach((input) => {
    input.disabled = !admin;
  });
}

function renderServer() {
  const enabled = Boolean(state.settings.serverEnabled);
  els.serverStateText.textContent = enabled
    ? "Active"
    : `Shutdown${state.settings.shutdownBy ? ` by ${state.settings.shutdownBy}` : ""}`;
  els.roomNameInput.value = state.settings.roomName || "Inner";
  els.signupMode.value = state.settings.signupMode || "request";
  els.requireContact.checked = state.settings.requireContact !== false;
  els.reportEmails.value = Array.isArray(state.settings.reportEmails) ? state.settings.reportEmails.join(", ") : "";
  els.serverEnabled.checked = enabled;

  const admin = isOwner();
  [els.roomNameInput, els.signupMode, els.requireContact, els.reportEmails, els.serverEnabled, els.saveServerButton, els.shutdownServerButton, els.restartServerButton].forEach((input) => {
    input.disabled = !admin;
  });
  els.shutdownServerButton.disabled = !admin || !enabled;
  els.restartServerButton.disabled = !admin || enabled;
}

function renderQuickEdit() {
  if (!els.quickEditForm) return;
  const admin = isOwner();
  els.quickEditForm.classList.toggle("hidden", !admin);
  if (!admin) return;
  const custom = state.settings.customizations || {};
  els.quickAppName.value = custom.appName || "";
  els.quickNotice.value = custom.notice || "";
  els.quickAccent.value = /^#[0-9a-f]{6}$/i.test(custom.accent || "") ? custom.accent : "#245c4f";
  els.quickDensity.value = custom.density || "comfortable";
  els.quickRounded.checked = custom.rounded !== false;
  els.quickCustomCss.value = custom.customCss || "";
}

function renderUsers() {
  if (!els.ownerPasswordForm) return;
  const admin = isOwner();
  [els.ownerPasswordForm, els.createAccountForm, els.accountManager, els.featureLockForm, els.roomForm].forEach((element) => {
    element.classList.toggle("hidden", !admin);
  });
  if (!admin) return;
  if (document.activeElement !== els.accountSearchInput) {
    els.accountSearchInput.value = state.accountSearch || "";
  }

  els.resetUser.replaceChildren(
    ...state.users.map((user) => {
      const option = document.createElement("option");
      option.value = user.username;
      option.textContent = `${user.username} (${user.role})`;
      return option;
    })
  );
  els.resetPasswordButton.disabled = state.users.length === 0;

  els.accountList.replaceChildren();
  const visibleUsers = filterUsersForAdmin(state.users);
  if (!state.users.length) {
    els.accountList.append(emptyBlock("No accounts yet"));
    return;
  }
  if (!visibleUsers.length) {
    els.accountList.append(emptyBlock("No accounts match that search"));
    return;
  }

  visibleUsers.forEach((user) => {
    const username = user.username.toLowerCase();
    const isMainAdmin = username === "admin";
    const isCurrentUser = state.user && username === state.user.username.toLowerCase();
    const item = document.createElement("article");
    item.className = "account-card";

    const head = document.createElement("div");
    head.className = "account-head";
    const name = document.createElement("strong");
    name.textContent = user.username;
    const badge = document.createElement("span");
    badge.className = "tag";
    badge.textContent = user.banned ? "Banned" : user.role;
    head.append(name, badge);

    const meta = document.createElement("div");
    meta.className = "account-meta";
    meta.append(textNode(`Access ${user.role}`));
    meta.append(textNode(`Persistent login ${user.allowPersistentLogin ? "allowed" : "off"}`));
    meta.append(textNode(`Created ${formatDate(user.createdAt) || "-"}`));
    if (user.createdBy) meta.append(textNode(`By ${user.createdBy}`));
    if (user.lastLoginAt) meta.append(textNode(`Last login ${formatDate(user.lastLoginAt)}`));
    if (user.lastLoginIp) meta.append(textNode(`From ${user.lastLoginIp}`));
    if (user.bannedUntil) meta.append(textNode(`Ban until ${formatDate(user.bannedUntil)}`));
    if (user.banReason) meta.append(textNode(user.banReason));

    const actions = document.createElement("div");
    actions.className = "account-actions";
    const roleButton = accountButton(`Change to ${nextRoleLabel(user.role)}`, () =>
      updateUser(user.username, { role: nextRole(user.role) })
    );
    roleButton.disabled = isMainAdmin;
    const persistentButton = accountButton(user.allowPersistentLogin ? "Disable persistent" : "Allow persistent", () =>
      updateUser(user.username, { allowPersistentLogin: !user.allowPersistentLogin })
    );
    const banShort = accountButton("Ban 15m", () => banUser(user.username, 15));
    const banHour = accountButton("Ban 1h", () => banUser(user.username, 60));
    const banDay = accountButton("Ban 24h", () => banUser(user.username, 1440));
    const unban = accountButton("Unban", () => banUser(user.username, 0));
    const remove = accountButton("Delete", () => deleteUser(user.username));
    banShort.disabled = isMainAdmin;
    banHour.disabled = isMainAdmin;
    banDay.disabled = isMainAdmin;
    unban.disabled = isMainAdmin;
    remove.disabled = isMainAdmin || isCurrentUser;
    actions.append(roleButton, persistentButton, banShort, banHour, banDay, unban, remove);

    item.append(head, meta, actions);
    els.accountList.append(item);
  });
}

function renderFeatureLocks() {
  if (!els.featureLockList) return;
  els.featureLockList.replaceChildren();
  const locks = Object.entries(state.settings.featureLocks || {});
  if (!locks.length) {
    els.featureLockList.append(emptyBlock("No active locks"));
    return;
  }

  locks.forEach(([feature, lock]) => {
    const item = document.createElement("article");
    item.className = "account-card";
    const head = document.createElement("div");
    head.className = "account-head";
    const name = document.createElement("strong");
    name.textContent = featureLabel(feature);
    const badge = document.createElement("span");
    badge.className = "tag";
    badge.textContent = "Locked";
    head.append(name, badge);

    const meta = document.createElement("div");
    meta.className = "account-meta";
    meta.append(textNode(`Until ${formatDate(lock.disabledUntil)}`));
    if (lock.disabledBy) meta.append(textNode(`By ${lock.disabledBy}`));
    if (lock.reason) meta.append(textNode(lock.reason));

    const unlock = accountButton("Unlock", () => quickFeatureUnlock(feature));
    item.append(head, meta, unlock);
    els.featureLockList.append(item);
  });
}

function renderRoomManager() {
  if (!els.roomManagerList) return;
  els.roomManagerList.replaceChildren();
  state.rooms.forEach((room) => {
    const item = document.createElement("article");
    item.className = "account-card";
    const head = document.createElement("div");
    head.className = "account-head";
    const name = document.createElement("strong");
    name.textContent = room.name;
    const badge = document.createElement("span");
    badge.className = "tag";
    badge.textContent = room.id === "main" ? "Main" : "Side";
    head.append(name, badge);

    const meta = document.createElement("div");
    meta.className = "account-meta";
    meta.append(textNode(`Created ${formatDate(room.createdAt) || "-"}`));
    if (room.createdBy) meta.append(textNode(`By ${room.createdBy}`));
    meta.append(textNode(room.private ? "Private room" : "Public room"));
    if (room.inviteOnly) meta.append(textNode("Invite only"));
    if (Array.isArray(room.allowedUsers) && room.allowedUsers.length) meta.append(textNode(`Allowed ${room.allowedUsers.join(", ")}`));

    const actions = document.createElement("div");
    actions.className = "account-actions";
    const open = accountButton("Open", () => {
      state.selectedRoomId = room.id;
      renderRooms();
      showView("messages");
      renderMessages();
    });
    const invite = accountButton("Invite", () => createRoomInvite(room.id, room.name));
    const remove = accountButton("Delete", () => deleteRoom(room.id));
    invite.disabled = room.id === "main";
    remove.disabled = room.id === "main";
    actions.append(open, invite, remove);

    item.append(head, meta, actions);
    els.roomManagerList.append(item);
  });
}

const serviceScaleLabels = [
  ["messages", "Messages", "Rate limit capacity"],
  ["dms", "DMs", "Direct and group message capacity"],
  ["uploads", "Uploads", "Maximum upload size"],
  ["voice", "Voice calls", "Voice and video call capacity"],
  ["screen", "Screen share", "Screen sharing capacity"],
  ["notifications", "Notifications", "Live alert capacity"],
  ["moderation", "Moderation", "Report and log processing"],
  ["realtime", "Realtime", "Socket reconnect and event flow"],
];

function defaultServiceScale() {
  return {
    messages: 100,
    dms: 100,
    uploads: 100,
    voice: 100,
    screen: 100,
    notifications: 100,
    moderation: 100,
    realtime: 100,
  };
}

function renderServiceScale() {
  if (!els.serviceScaleList) return;
  const admin = isOwner();
  els.serviceScaleForm.classList.toggle("hidden", !admin);
  if (!admin) return;
  const scale = { ...defaultServiceScale(), ...(state.settings.serviceScale || {}) };
  els.serviceScaleList.replaceChildren();
  serviceScaleLabels.forEach(([key, title, detail]) => {
    const row = document.createElement("label");
    row.className = "scale-row";
    const text = document.createElement("span");
    text.innerHTML = `<strong>${title}</strong><small>${detail}</small>`;
    const output = document.createElement("b");
    output.textContent = `${scale[key] || 100}%`;
    const input = document.createElement("input");
    input.type = "range";
    input.min = "25";
    input.max = "200";
    input.step = "5";
    input.value = String(scale[key] || 100);
    input.dataset.scaleKey = key;
    input.addEventListener("input", () => {
      output.textContent = `${input.value}%`;
    });
    row.append(text, input, output);
    els.serviceScaleList.append(row);
  });
}

function renderAdminDms() {
  if (!els.adminDmList || !isOwner()) return;
  const people = [
    { value: "all", label: "All DMs" },
    ...state.people.map((person) => ({ value: person.username, label: person.username })),
    ...(state.dmGroups || []).map((group) => ({ value: `group:${group.id}`, label: `Group: ${group.name}` })),
  ];
  els.adminDmFilter.replaceChildren(
    ...people.map((entry) => {
      const option = document.createElement("option");
      option.value = entry.value;
      option.textContent = entry.label;
      return option;
    })
  );
  if (!people.some((entry) => entry.value === state.adminDmFilter)) state.adminDmFilter = "all";
  els.adminDmFilter.value = state.adminDmFilter;

  els.adminDmList.replaceChildren();
  const visible =
    state.adminDmFilter === "all"
      ? state.dms
      : state.adminDmFilter.startsWith("group:")
        ? state.dms.filter((dm) => dm.groupId === state.adminDmFilter.slice(6))
        : state.dms.filter((dm) => dm.from === state.adminDmFilter || dm.to === state.adminDmFilter || (dm.participants || []).includes(state.adminDmFilter));

  if (!visible.length) {
    els.adminDmList.append(emptyBlock("No DMs to review"));
    return;
  }

  visible.slice(-250).forEach((dm) => {
    els.adminDmList.append(renderMessageBubble({
      mine: false,
      title: dmTitle(dm),
      text: dm.text,
      createdAt: dm.createdAt,
      sourceIp: dm.sourceIp,
      attachment: dm.attachment,
      onDelete: () => deleteDm(dm.id),
    }));
  });
}

function renderBackups() {
  if (!els.backupList || !isOwner()) return;
  els.backupList.replaceChildren();
  if (!state.backups.length) {
    els.backupList.append(emptyBlock("No backups yet"));
    return;
  }

  state.backups.forEach((backup) => {
    const item = document.createElement("article");
    item.className = "account-card";
    const head = document.createElement("div");
    head.className = "account-head";
    const name = document.createElement("strong");
    name.textContent = backup.fileName;
    const badge = document.createElement("span");
    badge.className = "tag";
    badge.textContent = formatBytes(backup.size);
    head.append(name, badge);

    const meta = document.createElement("div");
    meta.className = "account-meta";
    meta.append(textNode(`Created ${formatDate(backup.createdAt)}`));

    const actions = document.createElement("div");
    actions.className = "account-actions";
    const download = accountButton("Download", () => {
      downloadUrl(`/api/backups/${encodeURIComponent(backup.fileName)}`, backup.fileName);
    });
    const remove = accountButton("Delete", () => deleteBackup(backup.fileName));
    actions.append(download, remove);

    item.append(head, meta, actions);
    els.backupList.append(item);
  });
}

function renderAccountRequests() {
  if (!els.accountRequestList || !isOwner()) return;
  els.accountRequestList.replaceChildren();
  if (!state.accountRequests.length) {
    els.accountRequestList.append(emptyBlock("No account requests"));
    return;
  }

  state.accountRequests.slice(0, 150).forEach((request) => {
    const status = request.status || "pending";
    const location = request.location
      ? `${Number(request.location.latitude).toFixed(4)}, ${Number(request.location.longitude).toFixed(4)} accuracy ${Math.round(Number(request.location.accuracy || 0))}m`
      : "No location";
    const card = adminCard(request.username, status, [
      request.displayName ? `Name ${request.displayName}` : "",
      request.contact ? `Contact ${request.contact}` : "",
      request.note,
      `Location ${location}`,
      request.sourceIp ? `From ${request.sourceIp}` : "",
      `Requested ${formatDate(request.createdAt)}`,
      request.updatedBy ? `Updated by ${request.updatedBy}` : "",
    ].filter(Boolean));
    const actions = document.createElement("div");
    actions.className = "account-actions";
    const create = accountButton("Create account", () => approveAccountRequest(request.id, request.username));
    const reviewing = accountButton("Reviewing", () => updateAccountRequest(request.id, "reviewing"));
    const decline = accountButton("Decline", () => updateAccountRequest(request.id, "declined"));
    create.disabled = status === "approved";
    actions.append(create, reviewing, decline);
    card.append(actions);
    els.accountRequestList.append(card);
  });
}

function renderReports() {
  if (els.reportList && isOwner()) {
    els.reportList.replaceChildren();
    if (!state.reports.length) {
      els.reportList.append(emptyBlock("No reports"));
    } else {
      state.reports.slice(0, 100).forEach((report) => {
        els.reportList.append(adminCard(`${report.targetType} ${report.targetId}`, report.status, [
          `By ${report.reporter}`,
          report.reason,
          formatDate(report.createdAt),
        ]));
      });
    }
  }

  if (els.moderationLogList && isOwner()) {
    els.moderationLogList.replaceChildren();
    const visibleModerationLogs = filteredModerationLogs();
    if (!state.moderationLogs.length) {
      els.moderationLogList.append(emptyBlock("No moderation logs"));
    } else if (!visibleModerationLogs.length) {
      els.moderationLogList.append(emptyBlock("No moderation logs match those filters"));
    } else {
      visibleModerationLogs.slice(0, 120).forEach((log) => {
        els.moderationLogList.append(adminCard(log.action, log.actor, [
          log.target || "",
          log.note || "",
          formatDate(log.createdAt),
        ].filter(Boolean)));
      });
    }
  }
}

function renderLogs() {
  if (!els.logList || !isOwner()) return;
  if (document.activeElement !== els.logSearchInput) els.logSearchInput.value = state.logSearch || "";
  if (document.activeElement !== els.logDateInput) els.logDateInput.value = state.logDate || "";
  els.logList.replaceChildren();
  const visibleLogs = filteredSystemLogs();
  if (!state.logs.length) {
    els.logList.append(emptyBlock("No system logs yet"));
    return;
  }
  if (!visibleLogs.length) {
    els.logList.append(emptyBlock("No logs match those filters"));
    return;
  }
  visibleLogs.slice(0, 160).forEach((log) => {
    const details = log.details && typeof log.details === "object"
      ? Object.entries(log.details).slice(0, 4).map(([key, value]) => `${key}: ${Array.isArray(value) ? value.join(", ") : String(value)}`)
      : [];
    els.logList.append(adminCard(log.action || "event", log.actor || "system", [
      ...details,
      log.sourceIp ? `From ${log.sourceIp}` : "",
      formatDate(log.createdAt),
    ]));
  });
}

function renderHmd() {
  if (!els.hmdMetricGrid || !isDev()) return;
  const dev = state.dev || {};
  const config = dev.devConfig || {};
  const counts = dev.counts || {};
  const storage = dev.storage || {};
  els.hmdState.textContent = config.emergencyMode ? "Emergency mode active" : "Developer controls ready";
  els.hmdMetricGrid.replaceChildren(
    metricCard("Online", counts.online || 0, "Presence sessions"),
    metricCard("Users", counts.users || state.users.length || 0, "Accounts"),
    metricCard("Messages", counts.messages || state.messages.length || 0, "Stored messages"),
    metricCard("Requests", counts.accountRequests || state.accountRequests.length || 0, "Account intake"),
    metricCard("Logs", counts.logs || state.logs.length || 0, "System events"),
    metricCard("Storage", formatBytes(storage.totalUploadBytes || 0), "Uploaded files")
  );
  els.devEmergencyMode.checked = Boolean(config.emergencyMode);
  els.devMetricsEnabled.checked = config.metricsEnabled !== false;
  els.devTheme.value = config.theme || "midnight";

  els.databaseList.replaceChildren(
    adminCard("Rooms", String(counts.rooms || state.rooms.length || 0), ["Room/channel records"]),
    adminCard("DMs", String(counts.dms || state.dms.length || 0), ["Direct message records"]),
    adminCard("DM groups", String(counts.dmGroups || state.dmGroups.length || 0), ["Group conversation records"]),
    adminCard("Logs", String(counts.logs || state.logs.length || 0), ["System log records"]),
    adminCard("Reports", String(counts.reports || state.reports.length || 0), ["Moderation queue"]),
    adminCard("Orders", String(counts.orders || 0), ["Store order records"])
  );
  els.storageList.replaceChildren(
    adminCard("Uploads", String(storage.uploadCount || state.files.length || 0), [formatBytes(storage.totalUploadBytes || 0)]),
    adminCard("Inline backups", String(storage.inlineBackedCount || 0), [formatBytes(storage.inlineBytes || 0), `Limit ${formatBytes(storage.inlineLimitBytes || 0)}`]),
    adminCard("Data files", String(storage.dataFileCount || 0), [storage.dataDir || "data"])
  );
  renderLocalhostTools(dev.local || {});
  renderSimpleList(els.botList, state.bots, "No bots", (bot) => adminCard(bot.name, bot.enabled ? "Enabled" : "Off", [bot.description || "", bot.commandPrefix || "/"].filter(Boolean)));
  renderSimpleList(els.pluginList, state.plugins, "No plugins", (plugin) => adminCard(plugin.name, plugin.enabled ? "Enabled" : "Off", [plugin.hook || "", plugin.notes || ""].filter(Boolean)));

  els.automodEnabled.checked = Boolean(state.automod.enabled);
  els.automodWindow.value = state.automod.spamWindowSeconds || 8;
  els.automodMax.value = state.automod.maxMessagesPerWindow || 6;
  els.automodWords.value = (state.automod.mutedWords || []).join("\n");
}

function renderLocalhostTools(local) {
  if (!els.localhostToolList) return;
  els.localhostToolList.replaceChildren();
  const lanLinks = Array.isArray(local.lanLinks) ? local.lanLinks : [];
  const cards = [
    adminCard("Mode", local.localhostMode ? "Localhost" : "Cloud", [
      `Host ${local.host || "0.0.0.0"}`,
      `Port ${local.port || location.port || "80"}`,
      `Storage ${local.storageMode || "local"}`,
    ]),
    adminCard("Loopback", local.loopback || `${location.protocol}//127.0.0.1:${location.port || "3000"}`, [
      "Use this on the same PC running Inner.",
    ]),
    adminCard("Data folder", local.dataDir || "data", [
      local.uploadDir ? `Uploads ${local.uploadDir}` : "",
      local.cloudRequired ? "Cloud storage required" : "Local upload fallback allowed",
    ].filter(Boolean)),
  ];
  cards.forEach((card, index) => {
    const actions = document.createElement("div");
    actions.className = "account-actions";
    if (index === 1 && local.loopback) {
      actions.append(accountButton("Copy", () => copyText(local.loopback)));
    }
    card.append(actions);
    els.localhostToolList.append(card);
  });
  if (lanLinks.length) {
    lanLinks.forEach((link) => {
      const card = adminCard("LAN link", link, ["Use on phones or other devices on the same Wi-Fi."]);
      const actions = document.createElement("div");
      actions.className = "account-actions";
      actions.append(accountButton("Copy", () => copyText(link)));
      card.append(actions);
      els.localhostToolList.append(card);
    });
  } else {
    els.localhostToolList.append(adminCard("LAN link", "Not detected", ["Start localhost mode on Wi-Fi to expose a phone testing URL."]));
  }
}

function renderSimpleList(container, items, emptyText, factory) {
  container.replaceChildren();
  if (!items || !items.length) {
    container.append(emptyBlock(emptyText));
    return;
  }
  items.forEach((item) => container.append(factory(item)));
}

function renderAdminStore() {
  if (!isOwner()) return;
  if (els.adminStoreList) {
    els.adminStoreList.replaceChildren();
    const items = state.store.items || [];
    if (!items.length) {
      els.adminStoreList.append(emptyBlock("No paid items"));
    } else {
      items.forEach((item) => {
        const card = adminCard(item.name, formatMoney(item.priceCents, item.currency), [
          item.description || "No description",
          item.paymentLink ? `Payment link ${item.paymentLink}` : "No payment link",
          `Created ${formatDate(item.createdAt)}`,
        ]);
        const actions = document.createElement("div");
        actions.className = "account-actions";
        actions.append(accountButton("Delete", () => deleteStoreItem(item.id)));
        card.append(actions);
        els.adminStoreList.append(card);
      });
    }
  }
  if (els.adminOrderList) renderOrders(els.adminOrderList, state.store.orders || [], true);
}

function renderOrders(container, orders, adminMode) {
  container.replaceChildren();
  if (!orders.length) {
    container.append(emptyBlock("No orders yet"));
    return;
  }
  orders.forEach((order) => {
    const card = adminCard(`${order.itemName}`, order.status, [
      `${formatMoney(order.priceCents, order.currency)} by ${order.user}`,
      `Created ${formatDate(order.createdAt)}`,
      order.note ? `Note: ${order.note}` : "",
      order.sourceIp && adminMode ? `From ${order.sourceIp}` : "",
    ].filter(Boolean));
    if (adminMode) {
      const actions = document.createElement("div");
      actions.className = "account-actions";
      ["pending", "paid", "cancelled", "refunded"].forEach((status) => {
        actions.append(accountButton(status, () => updateOrder(order.id, status)));
      });
      card.append(actions);
    } else if (order.paymentLink && order.status === "pending") {
      const actions = document.createElement("div");
      actions.className = "account-actions";
      actions.append(accountButton("Pay link", () => window.open(order.paymentLink, "_blank", "noopener")));
      card.append(actions);
    }
    container.append(card);
  });
}

function renderAiRequests() {
  if (!els.aiResponseList || !isOwner()) return;
  if (els.aiState) {
    els.aiState.textContent = state.aiConfigured
      ? "AI key is configured. Ask for small safe changes."
      : "AI key is not configured. Add a key below or start Inner with OPENAI_API_KEY set.";
  }
  els.aiResponseList.replaceChildren();
  if (!state.aiRequests.length) {
    els.aiResponseList.append(emptyBlock("No AI requests yet"));
    return;
  }
  state.aiRequests.slice().reverse().forEach((request) => {
    const card = adminCard(request.prompt, request.configured ? "AI" : "Saved", [
      request.response,
      `By ${request.createdBy} at ${formatDate(request.createdAt)}`,
    ]);
    els.aiResponseList.append(card);
  });
}

function updateControls() {
  const serverEnabled = Boolean(state.settings.serverEnabled) || isOwner();
  const room = state.rooms.find((entry) => entry.id === state.selectedRoomId) || { id: "main" };
  const messagesEnabled = serverEnabled && featureAvailable("messages") && (room.id === "main" || featureAvailable("rooms"));
  const dmsEnabled = serverEnabled && featureAvailable("dms") && Boolean(state.selectedDmUser);
  const filesEnabled = serverEnabled && featureAvailable("files");
  const screenEnabled = serverEnabled && featureAvailable("screen");
  const friendsEnabled = serverEnabled && featureAvailable("friends");
  const voiceEnabled = serverEnabled && featureAvailable("voice");
  const invitesEnabled = serverEnabled && featureAvailable("invites");
  const dmCallReady = dmsEnabled && Boolean(currentDmCallRoom());
  els.roomSelect.disabled = !featureAvailable("rooms") && room.id !== "main";
  els.inviteCodeInput.disabled = !invitesEnabled;
  els.joinInviteButton.disabled = !invitesEnabled;
  els.messageInput.disabled = !messagesEnabled;
  els.messageAttachment.disabled = !messagesEnabled;
  els.messageSelfieButton.disabled = !messagesEnabled;
  els.sendMessageButton.disabled = !messagesEnabled;
  els.dmPeerSelect.disabled = !dmsEnabled && !state.selectedDmUser;
  els.dmInput.disabled = !dmsEnabled;
  els.dmAttachment.disabled = !dmsEnabled;
  els.dmSelfieButton.disabled = !dmsEnabled;
  els.sendDmButton.disabled = !dmsEnabled;
  els.dmGroupName.disabled = !dmsEnabled;
  els.dmGroupMembers.classList.toggle("disabled", !dmsEnabled);
  els.dmGroupMembers.querySelectorAll("input").forEach((input) => {
    input.disabled = !dmsEnabled;
  });
  els.createDmGroupButton.disabled = !dmsEnabled || (!isOwner() && dmGroupCandidatePeople().length < 2);
  els.dmVoiceCallButton.disabled = !dmCallReady || Boolean(state.voiceStream);
  els.dmVideoCallButton.disabled = !dmCallReady || Boolean(state.voiceStream);
  els.dmShareScreenButton.disabled = !dmCallReady || Boolean(state.localStream) || !screenEnabled;
  els.dmStopScreenButton.disabled = !(state.localStream && state.screenRoomId === currentDmCallRoom());
  els.dmLeaveCallButton.disabled = !(state.voiceStream && state.voiceRoomId === currentDmCallRoom());
  els.fileInput.disabled = !filesEnabled;
  els.fileCategory.disabled = !filesEnabled;
  els.privateUpload.disabled = !filesEnabled;
  els.uploadButton.disabled = !filesEnabled;
  els.friendUserSelect.disabled = !friendsEnabled;
  els.sendFriendRequestButton.disabled = !friendsEnabled;
  els.joinVoiceButton.disabled = !voiceEnabled || Boolean(state.voiceStream);
  els.joinVideoButton.disabled = !voiceEnabled || Boolean(state.voiceStream);
  els.cameraVoiceButton.disabled = !voiceEnabled || !Boolean(state.voiceStream) || !state.voiceVideoEnabled;
  els.startShareButton.disabled = !screenEnabled || Boolean(state.localStream);
  document.querySelectorAll("[data-soundboard]").forEach((button) => {
    button.disabled = !voiceEnabled || !Boolean(state.voiceStream);
  });
}

function addMessage(message) {
  if (state.messages.some((entry) => entry.id === message.id)) return;
  message.roomId = message.roomId || "main";
  state.messages.push(message);
  state.messages = state.messages.slice(-500);
  renderShell();
  renderMessages();
}

function addDm(dm) {
  if (state.dms.some((entry) => entry.id === dm.id)) return;
  state.dms.push(dm);
  state.dms = state.dms.slice(-500);
  renderDms();
  renderAdminDms();
}

function addFile(file) {
  if (state.files.some((entry) => entry.id === file.id)) return;
  state.files.unshift(file);
  renderShell();
  renderFiles();
}

function queueOutgoingMessage(item) {
  const localId = `local-${Date.now()}-${Math.random().toString(16).slice(2)}`;
  const queued = {
    ...item,
    localId,
    status: "pending",
    createdAt: new Date().toISOString(),
  };
  if (queued.kind === "message") {
    state.messages.push({
      id: localId,
      localId,
      local: true,
      status: "pending",
      roomId: queued.roomId || "main",
      parentId: queued.parentId || "",
      text: queued.text,
      attachment: queued.attachment,
      mentions: mentionNames(queued.text),
      reactions: {},
      user: state.user.username,
      createdAt: queued.createdAt,
    });
    state.pendingSends.push(queued);
    renderShell();
    renderMessages();
  } else {
    state.dms.push({
      id: localId,
      localId,
      local: true,
      status: "pending",
      kind: queued.groupId ? "group" : "direct",
      from: state.user.username,
      to: queued.groupId ? currentDmCallLabel() : queued.to,
      groupId: queued.groupId || "",
      groupName: queued.groupId ? currentDmCallLabel() : "",
      participants: selectedDmParticipants(),
      text: queued.text,
      attachment: queued.attachment,
      createdAt: queued.createdAt,
    });
    state.pendingSends.push(queued);
    renderDms();
  }
  savePendingSends();
  sendPendingItem(queued).catch(() => {});
}

async function sendPendingItem(item) {
  if (item.sending) return;
  item.sending = true;
  try {
    const payload = item.kind === "message"
      ? { text: item.text, attachment: item.attachment, roomId: item.roomId || "main", parentId: item.parentId || "" }
      : { to: item.to || "", groupId: item.groupId || "", text: item.text, attachment: item.attachment };
    const data = await api(item.kind === "message" ? "/api/messages" : "/api/dms", {
      method: "POST",
      json: payload,
    });
    state.pendingSends = state.pendingSends.filter((entry) => entry.localId !== item.localId);
    if (item.kind === "message") {
      state.messages = state.messages.filter((entry) => entry.localId !== item.localId);
      addMessage(data.message);
    } else {
      state.dms = state.dms.filter((entry) => entry.localId !== item.localId);
      addDm(data.dm);
    }
    savePendingSends();
  } catch (error) {
    item.sending = false;
    markPendingFailed(item.localId, error.message || "Send failed");
  }
}

function markPendingFailed(localId, errorMessage) {
  const pending = state.pendingSends.find((entry) => entry.localId === localId);
  if (pending) {
    pending.status = "failed";
    pending.error = errorMessage;
  }
  [...state.messages, ...state.dms].forEach((entry) => {
    if (entry.localId === localId) {
      entry.status = "failed";
      entry.error = errorMessage;
    }
  });
  savePendingSends();
  renderMessages();
  renderDms();
}

function retryPending(localId) {
  const pending = state.pendingSends.find((entry) => entry.localId === localId);
  if (!pending) return;
  pending.status = "pending";
  [...state.messages, ...state.dms].forEach((entry) => {
    if (entry.localId === localId) entry.status = "pending";
  });
  savePendingSends();
  renderMessages();
  renderDms();
  sendPendingItem(pending).catch(() => {});
}

function flushPendingSends() {
  if (!state.pendingSends.length) return;
  state.pendingSends.forEach((entry) => {
    entry.status = "pending";
    sendPendingItem(entry).catch(() => {});
  });
}

function savePendingSends() {
  try {
    localStorage.setItem("innerPendingSends", JSON.stringify(state.pendingSends.slice(-50)));
  } catch (error) {
    // Pending recovery is best effort.
  }
}

function restorePendingSends() {
  try {
    state.pendingSends = JSON.parse(localStorage.getItem("innerPendingSends") || "[]").filter((entry) => entry && entry.localId);
  } catch (error) {
    state.pendingSends = [];
  }
  state.pendingSends.forEach((queued) => {
    if (queued.kind === "message" && !state.messages.some((entry) => entry.localId === queued.localId)) {
      state.messages.push({
        id: queued.localId,
        localId: queued.localId,
        local: true,
        status: queued.status || "failed",
        roomId: queued.roomId || "main",
        parentId: queued.parentId || "",
        text: queued.text,
        attachment: queued.attachment,
        reactions: {},
        user: state.user.username,
        createdAt: queued.createdAt || new Date().toISOString(),
      });
    } else if (queued.kind === "dm" && !state.dms.some((entry) => entry.localId === queued.localId)) {
      state.dms.push({
        id: queued.localId,
        localId: queued.localId,
        local: true,
        status: queued.status || "failed",
        kind: queued.groupId ? "group" : "direct",
        from: state.user.username,
        to: queued.groupId ? "Group" : queued.to,
        groupId: queued.groupId || "",
        groupName: queued.groupId ? "Group" : "",
        participants: [],
        text: queued.text,
        attachment: queued.attachment,
        createdAt: queued.createdAt || new Date().toISOString(),
      });
    }
  });
}

function mentionNames(text) {
  return Array.from(new Set(String(text || "").match(/@([a-zA-Z0-9._-]{3,32})/g) || [])).map((entry) => entry.slice(1));
}

async function deleteMessage(id) {
  if (!isOwner()) return notify("Admin access required");
  try {
    await api(`/api/messages/${encodeURIComponent(id)}`, { method: "DELETE" });
  } catch (error) {
    notify(error.message);
  }
}

async function editMessage(id, currentText) {
  const text = window.prompt("Edit message", currentText || "");
  if (!text || text.trim() === currentText) return;
  try {
    const data = await api(`/api/messages/${encodeURIComponent(id)}`, {
      method: "PATCH",
      json: { text },
    });
    const index = state.messages.findIndex((entry) => entry.id === id);
    if (index !== -1) state.messages[index] = data.message;
    renderMessages();
  } catch (error) {
    notify(error.message);
  }
}

async function editDm(id, currentText) {
  const text = window.prompt("Edit DM", currentText || "");
  if (!text || text.trim() === currentText) return;
  try {
    const data = await api(`/api/dms/${encodeURIComponent(id)}`, {
      method: "PATCH",
      json: { text },
    });
    const index = state.dms.findIndex((entry) => entry.id === id);
    if (index !== -1) state.dms[index] = data.dm;
    renderDms();
  } catch (error) {
    notify(error.message);
  }
}

async function reactMessage(id, emoji) {
  try {
    const data = await api(`/api/messages/${encodeURIComponent(id)}/reactions`, {
      method: "POST",
      json: { emoji },
    });
    const index = state.messages.findIndex((entry) => entry.id === id);
    if (index !== -1) state.messages[index] = data.message;
    renderMessages();
  } catch (error) {
    notify(error.message);
  }
}

async function reportMessage(id) {
  const reason = window.prompt("Why are you reporting this message?") || "";
  if (!reason.trim()) return;
  try {
    await api("/api/reports", {
      method: "POST",
      json: { targetType: "message", targetId: id, reason },
    });
    notify("Report sent");
  } catch (error) {
    notify(error.message);
  }
}

async function deleteFile(id) {
  if (!isOwner()) return notify("Admin access required");
  try {
    await api(`/api/files/${encodeURIComponent(id)}`, { method: "DELETE" });
  } catch (error) {
    notify(error.message);
  }
}

async function requestStoreItem(itemId) {
  try {
    const note = window.prompt("Optional note for admin") || "";
    const data = await api("/api/store/orders", {
      method: "POST",
      json: { itemId, note },
    });
    state.store = data.store || state.store;
    renderStore();
    notify("Request sent");
    if (data.order && data.order.paymentLink) window.open(data.order.paymentLink, "_blank", "noopener");
  } catch (error) {
    notify(error.message);
  }
}

async function deleteStoreItem(id) {
  if (!isOwner()) return notify("Admin access required");
  if (!window.confirm("Delete this paid item?")) return;
  try {
    const data = await api(`/api/store/items/${encodeURIComponent(id)}`, { method: "DELETE" });
    state.store = data.store || state.store;
    renderStore();
    renderAdminStore();
    notify("Item deleted");
  } catch (error) {
    notify(error.message);
  }
}

async function updateOrder(id, status) {
  if (!isOwner()) return notify("Admin access required");
  try {
    const data = await api("/api/store/orders/update", {
      method: "POST",
      json: { id, status },
    });
    state.store = data.store || state.store;
    renderStore();
    renderAdminStore();
    notify("Order updated");
  } catch (error) {
    notify(error.message);
  }
}

async function deleteDm(id) {
  if (!isOwner()) return notify("Admin access required");
  try {
    await api(`/api/dms/${encodeURIComponent(id)}`, { method: "DELETE" });
  } catch (error) {
    notify(error.message);
  }
}

async function deleteRoom(id) {
  if (!isOwner()) return notify("Admin access required");
  if (id === "main") return notify("Main room cannot be deleted");
  if (!window.confirm("Delete this room and its messages?")) return;
  try {
    const data = await api(`/api/rooms/${encodeURIComponent(id)}`, { method: "DELETE" });
    state.rooms = data.rooms || state.rooms.filter((room) => room.id !== id);
    state.messages = state.messages.filter((entry) => (entry.roomId || "main") !== id);
    if (state.selectedRoomId === id) state.selectedRoomId = "main";
    renderRooms();
    renderMessages();
    renderRoomManager();
    notify("Room deleted");
  } catch (error) {
    notify(error.message);
  }
}

async function quickFeatureUnlock(feature) {
  if (!isOwner()) return notify("Admin access required");
  try {
    const data = await api("/api/features/lock", {
      method: "POST",
      json: { feature, minutes: 0 },
    });
    state.settings = data.settings || state.settings;
    renderAll();
    notify("Feature unlocked");
  } catch (error) {
    notify(error.message);
  }
}

async function deleteBackup(fileName) {
  if (!isOwner()) return notify("Admin access required");
  if (!window.confirm("Delete this backup?")) return;
  try {
    const data = await api(`/api/backups/${encodeURIComponent(fileName)}`, { method: "DELETE" });
    state.backups = data.backups || [];
    renderBackups();
    notify("Backup deleted");
  } catch (error) {
    notify(error.message);
  }
}

async function updateAccountRequest(id, status) {
  if (!isOwner()) return notify("Admin access required");
  try {
    const data = await api("/api/account-requests/update", {
      method: "POST",
      json: { id, status },
    });
    state.accountRequests = data.accountRequests || state.accountRequests;
    renderAccountRequests();
    notify("Request updated");
  } catch (error) {
    notify(error.message);
  }
}

async function approveAccountRequest(id, username) {
  if (!isOwner()) return notify("Admin access required");
  const password = window.prompt(`Set a password for ${username}`);
  if (!password) return;
  try {
    const data = await api("/api/account-requests/approve", {
      method: "POST",
      json: { id, password, role: "member" },
    });
    state.users = data.users || state.users;
    state.accountRequests = data.accountRequests || state.accountRequests;
    renderUsers();
    renderAccountRequests();
    renderDms();
    notify("Account created");
  } catch (error) {
    notify(error.message);
  }
}

function accountButton(label, onClick) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = "ghost-light-button compact-button";
  button.textContent = label;
  button.addEventListener("click", onClick);
  return button;
}

function nextRole(role) {
  const roles = isDev() ? ["member", "moderator", "admin", "hmd", "dev"] : ["member", "moderator", "admin"];
  const index = roles.indexOf(role);
  return roles[(index + 1) % roles.length];
}

function nextRoleLabel(role) {
  return nextRole(role);
}

function adminCard(titleText, badgeText, lines) {
  const item = document.createElement("article");
  item.className = "account-card";
  const head = document.createElement("div");
  head.className = "account-head";
  const title = document.createElement("strong");
  title.textContent = titleText;
  const badge = document.createElement("span");
  badge.className = "tag";
  badge.textContent = badgeText;
  head.append(title, badge);
  const meta = document.createElement("div");
  meta.className = "account-meta";
  lines.filter(Boolean).forEach((line) => meta.append(textNode(line)));
  item.append(head, meta);
  return item;
}

async function updateUser(username, changes) {
  if (!isOwner()) return notify("Admin access required");
  const existing = state.users.find((user) => user.username === username) || {};
  try {
    const data = await api("/api/users/update", {
      method: "POST",
      json: {
        username,
        role: changes.role || existing.role || "member",
        allowPersistentLogin:
          typeof changes.allowPersistentLogin === "boolean"
            ? changes.allowPersistentLogin
            : Boolean(existing.allowPersistentLogin),
      },
    });
    state.users = data.users || state.users;
    renderUsers();
    notify("Account updated");
  } catch (error) {
    notify(error.message);
  }
}

async function banUser(username, minutes) {
  if (!isOwner()) return notify("Admin access required");
  try {
    const data = await api("/api/users/ban", {
      method: "POST",
      json: {
        username,
        minutes,
        reason: minutes ? `Temporary ban for ${minutes} minutes` : "",
      },
    });
    state.users = data.users || state.users;
    renderUsers();
    notify(minutes ? "Account banned" : "Account unbanned");
  } catch (error) {
    notify(error.message);
  }
}

async function deleteUser(username) {
  if (!isOwner()) return notify("Admin access required");
  if (!window.confirm(`Delete account ${username}?`)) return;
  try {
    const data = await api(`/api/users/${encodeURIComponent(username)}`, { method: "DELETE" });
    state.users = data.users || state.users;
    renderUsers();
    notify("Account deleted");
  } catch (error) {
    notify(error.message);
  }
}

function filterUsersForAdmin(users) {
  const term = String(state.accountSearch || "").trim().toLowerCase();
  if (!term) return users;
  return (users || []).filter((user) => {
    const profile = state.profiles[user.username] || {};
    return searchableText({
      ...user,
      profile,
      lastLoginDevice: user.lastLoginDevice || "",
      banReason: user.banReason || "",
    }).includes(term);
  });
}

function filteredSystemLogs() {
  return filterLogEntries(state.logs || [], (log) => searchableText({
    action: log.action,
    actor: log.actor,
    sourceIp: log.sourceIp,
    sourceDevice: log.sourceDevice,
    details: log.details,
    createdAt: log.createdAt,
  }));
}

function filteredModerationLogs() {
  return filterLogEntries(state.moderationLogs || [], (log) => searchableText(log));
}

function filterLogEntries(entries, textFactory) {
  const term = String(state.logSearch || "").trim().toLowerCase();
  const day = String(state.logDate || "").trim();
  return entries.filter((entry) => {
    const createdDay = String(entry.createdAt || "").slice(0, 10);
    if (day && createdDay !== day) return false;
    if (term && !textFactory(entry).includes(term)) return false;
    return true;
  });
}

function searchableText(value) {
  try {
    return JSON.stringify(value || {}).toLowerCase();
  } catch (error) {
    return String(value || "").toLowerCase();
  }
}

function dmPeople() {
  const current = state.user ? state.user.username.toLowerCase() : "";
  const direct = (state.people || [])
    .filter((person) => canStartDirectDmWith(person, current))
    .map((person) => ({
      ...person,
      value: person.username,
      label: `${person.displayName || person.username} (${person.role})`,
    }))
    .sort((a, b) => a.username.localeCompare(b.username));
  const groups = (state.dmGroups || [])
    .filter((group) => Array.isArray(group.participants) && group.participants.includes(state.user.username))
    .map((group) => ({
      username: group.name,
      role: "group",
      value: `group:${group.id}`,
      label: `${group.name} (group, ${group.participantCount || group.participants.length})`,
    }))
    .sort((a, b) => a.username.localeCompare(b.username));
  return [...groups, ...direct];
}

function dmGroupCandidatePeople() {
  const current = state.user ? state.user.username.toLowerCase() : "";
  return (state.people || [])
    .filter((person) => canStartDirectDmWith(person, current))
    .sort((a, b) => String(a.username).localeCompare(String(b.username)));
}

function canStartDirectDmWith(person, currentUsername) {
  if (!person || !person.username || person.username.toLowerCase() === currentUsername || person.banned) return false;
  if (isOwner()) return true;
  return acceptedFriendNames().has(person.username.toLowerCase());
}

function acceptedFriendNames() {
  return new Set((state.friends.friends || []).map((friend) => String(friend.username || "").toLowerCase()).filter(Boolean));
}

function selectedDmGroup() {
  if (!state.selectedDmUser || !state.selectedDmUser.startsWith("group:")) return null;
  const id = state.selectedDmUser.slice(6);
  return (state.dmGroups || []).find((group) => group.id === id) || null;
}

function dmBetween(dm, first, target) {
  if (String(target || "").startsWith("group:")) {
    const groupId = String(target).slice(6);
    return dm.groupId === groupId && Array.isArray(dm.participants) && dm.participants.includes(first);
  }
  const pair = new Set([String(first || ""), String(target || "")]);
  return pair.has(dm.from) && pair.has(dm.to) && !dm.groupId;
}

function dmTitle(dm) {
  if (dm.groupId) return `${dm.from} in ${dm.groupName || dm.to || "Group DM"}`;
  return `${dm.from} to ${dm.to}`;
}

function currentDmCallRoom() {
  if (!state.user || !state.selectedDmUser) return "";
  if (state.selectedDmUser.startsWith("group:")) return state.selectedDmUser;
  const users = [state.user.username, state.selectedDmUser].sort((a, b) => a.localeCompare(b));
  return `dm:${users[0]}:${users[1]}`;
}

function currentDmCallLabel() {
  if (!state.selectedDmUser) return "DM";
  const selected = dmPeople().find((person) => person.value === state.selectedDmUser);
  return selected ? selected.label.replace(/\s*\([^)]*\)$/, "") : callRoomLabel(currentDmCallRoom());
}

function callRoomLabel(roomId) {
  const room = String(roomId || "");
  if (room.startsWith("group:")) {
    const group = state.dmGroups.find((entry) => `group:${entry.id}` === room);
    return group ? group.name : "Group call";
  }
  if (room.startsWith("dm:")) {
    return room.split(":").slice(1).filter((name) => name !== (state.user && state.user.username)).join(" + ") || "DM call";
  }
  return room === "lobby" ? "Lobby Voice" : "Voice";
}

function selectedDmParticipants() {
  if (!state.user || !state.selectedDmUser) return [];
  if (state.selectedDmUser.startsWith("group:")) {
    const groupId = state.selectedDmUser.slice(6);
    const group = state.dmGroups.find((entry) => entry.id === groupId);
    return group && Array.isArray(group.participants) ? group.participants : [];
  }
  return [state.user.username, state.selectedDmUser];
}

function screenPeersForRoom(roomId) {
  if (!isDmCallRoom(roomId)) return Array.from(state.peers.values());
  const participants = new Set(callRoomParticipants(roomId));
  return Array.from(state.peers.values()).filter((peer) => participants.has(peer.username));
}

function canPeerReceiveScreen(peer) {
  if (!state.screenRoomId || !isDmCallRoom(state.screenRoomId)) return true;
  return callRoomParticipants(state.screenRoomId).includes(peer.username);
}

function callRoomParticipants(roomId) {
  const room = String(roomId || "");
  if (room.startsWith("group:")) {
    const group = state.dmGroups.find((entry) => `group:${entry.id}` === room);
    return group && Array.isArray(group.participants) ? group.participants : [];
  }
  if (room.startsWith("dm:")) return room.split(":").slice(1).filter(Boolean);
  return [];
}

function isDmCallRoom(roomId) {
  const room = String(roomId || "");
  return room.startsWith("dm:") || room.startsWith("group:");
}

function selectDmFromCallRoom(roomId) {
  const room = String(roomId || "");
  if (room.startsWith("group:")) {
    state.selectedDmUser = room;
  } else if (room.startsWith("dm:") && state.user) {
    state.selectedDmUser = room.split(":").slice(1).find((name) => name !== state.user.username) || state.selectedDmUser;
  }
  saveUiState();
  renderDms();
}

function featureLock(feature) {
  const lock = (state.settings.featureLocks || {})[feature];
  if (!lock) return null;
  const until = Date.parse(lock.disabledUntil);
  if (!Number.isFinite(until) || until <= Date.now()) return null;
  return lock;
}

function featureAvailable(feature) {
  return isOwner() || !featureLock(feature);
}

function lockMessage(feature) {
  const lock = featureLock(feature);
  if (!lock) return "";
  return `${featureLabel(feature)} disabled until ${formatDate(lock.disabledUntil)}`;
}

function featureLabel(feature) {
  const labels = {
    dms: "DMs",
    files: "Files",
    messages: "Messages",
    rooms: "Side rooms",
    screen: "Screen",
    vpn: "VPN",
  };
  return labels[feature] || feature;
}

function renderMessageBubble({ mine, title, text, createdAt, sourceIp, attachment, onDelete }) {
  const item = document.createElement("article");
  item.className = `message ${mine ? "mine" : ""}`;

  const meta = document.createElement("div");
  meta.className = "message-meta";
  meta.append(textNode(title), textNode(formatDate(createdAt)));
  if (isOwner() && sourceIp) meta.append(textNode(`From ${sourceIp}`));

  const body = document.createElement("div");
  body.className = "message-text";
  body.textContent = text;
  item.append(meta, body);
  appendMessageAttachment(item, attachment);

  if (onDelete) {
    const actions = document.createElement("div");
    actions.className = "message-actions";
    const deleteButton = document.createElement("button");
    deleteButton.className = "ghost-light-button compact-button";
    deleteButton.type = "button";
    deleteButton.textContent = "Delete";
    deleteButton.addEventListener("click", onDelete);
    actions.append(deleteButton);
    item.append(actions);
  }

  return item;
}

function showIncomingMessageAlert(message) {
  const room = state.rooms.find((entry) => entry.id === (message.roomId || "main")) || { name: "Main" };
  const title = `${message.user} in ${room.name}`;
  const body = previewText(message.text);
  notify(`${title}: ${body}`);
  showSystemAlert(title, body, `message-${message.id}`, () => {
    state.selectedRoomId = message.roomId || "main";
    renderRooms();
    showView("messages");
    renderMessages();
  });
}

function showIncomingDmAlert(dm) {
  const title = dm.groupId ? `${dm.from} in ${dm.groupName || "Group DM"}` : `DM from ${dm.from}`;
  const body = previewText(dm.text);
  notify(`${title}: ${body}`);
  showSystemAlert(title, body, `dm-${dm.id}`, () => {
    state.selectedDmUser = dm.groupId ? `group:${dm.groupId}` : dm.from === state.user.username ? dm.to : dm.from;
    showView("dms");
    renderDms();
  });
}

function showLiveAlert(body, options = {}) {
  notify(body);
  showSystemAlert(options.title || "Inner live call", body, `call-${Date.now()}`, () => {
    if (state.incomingCall) {
      selectDmFromCallRoom(state.incomingCall.roomId);
      showView("dms");
      renderDmCall();
    }
  });
}

function unlockRingtone() {
  try {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextClass) return;
    state.ringtoneContext = state.ringtoneContext || new AudioContextClass();
    if (state.ringtoneContext.state === "suspended") state.ringtoneContext.resume().catch(() => {});
  } catch (error) {
    // AudioContext can be blocked until the browser allows sound.
  }
}

function playRingtone() {
  unlockRingtone();
  stopRingtone();
  const context = state.ringtoneContext;
  if (!context) return;
  let count = 0;
  state.ringtoneTimer = setInterval(() => {
    try {
      const oscillator = context.createOscillator();
      const gain = context.createGain();
      oscillator.type = "sine";
      oscillator.frequency.value = count % 2 ? 740 : 520;
      gain.gain.setValueAtTime(0.0001, context.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.18, context.currentTime + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, context.currentTime + 0.32);
      oscillator.connect(gain);
      gain.connect(context.destination);
      oscillator.start();
      oscillator.stop(context.currentTime + 0.34);
      count += 1;
      if (count > 10) stopRingtone();
    } catch (error) {
      stopRingtone();
    }
  }, 650);
}

function stopRingtone() {
  if (state.ringtoneTimer) clearInterval(state.ringtoneTimer);
  state.ringtoneTimer = null;
}

function playSoundboard(sound, options = {}) {
  unlockRingtone();
  const context = state.ringtoneContext;
  if (!context) return;
  const roomId = state.voiceRoomId || currentDmCallRoom() || "lobby";
  const patterns = {
    chime: [523, 659, 784],
    ping: [880],
    pop: [220, 180],
    ring: [440, 554, 440, 554],
  };
  const tones = patterns[sound] || patterns.chime;
  tones.forEach((frequency, index) => {
    try {
      const oscillator = context.createOscillator();
      const gain = context.createGain();
      oscillator.type = sound === "pop" ? "square" : "sine";
      oscillator.frequency.value = frequency;
      const start = context.currentTime + index * 0.12;
      gain.gain.setValueAtTime(0.0001, start);
      gain.gain.exponentialRampToValueAtTime(0.16, start + 0.015);
      gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.14);
      oscillator.connect(gain);
      gain.connect(context.destination);
      oscillator.start(start);
      oscillator.stop(start + 0.16);
    } catch (error) {
      // Soundboard is optional on browsers that block audio.
    }
  });
  if (options.broadcast) {
    sendWs({ type: "soundboard:play", roomId, sound });
  }
}

function showSystemAlert(title, body, tag, onClick) {
  if (!state.notificationsEnabled) return;
  if (!("Notification" in window) || Notification.permission !== "granted") return;
  if (document.visibilityState === "visible" && document.hasFocus()) return;

  try {
    const alert = new Notification(title, {
      body,
      icon: "/icon.svg",
      tag,
    });
    alert.onclick = () => {
      window.focus();
      if (typeof onClick === "function") onClick();
      alert.close();
    };
  } catch (error) {
    // Some browsers only allow notifications on localhost or HTTPS.
  }
}

function updateNotificationButton() {
  if (!els.notificationsButton) return;
  if (!("Notification" in window)) {
    els.notificationsButton.textContent = "Alerts unavailable";
    els.notificationsButton.disabled = true;
    return;
  }
  if (Notification.permission === "denied") {
    els.notificationsButton.textContent = "Alerts blocked";
    els.notificationsButton.disabled = false;
    return;
  }
  if (state.notificationsEnabled && Notification.permission === "granted") {
    els.notificationsButton.textContent = "Alerts on";
  } else {
    els.notificationsButton.textContent = "Enable alerts";
  }
  els.notificationsButton.disabled = false;
}

function previewText(value) {
  const text = String(value || "").replace(/\s+/g, " ").trim();
  return text.length > 90 ? `${text.slice(0, 87)}...` : text;
}

function viewFromPath() {
  const path = window.location.pathname.replace(/\/+$/, "") || "/";
  return Object.entries(viewRoutes).find(([, route]) => route === path)?.[0] || "";
}

function restoreUiState() {
  try {
    state.activeView = viewFromPath() || localStorage.getItem("innerActiveView") || "messages";
    state.selectedRoomId = localStorage.getItem("innerSelectedRoom") || "main";
    state.selectedDmUser = localStorage.getItem("innerSelectedDm") || "";
  } catch (error) {
    state.activeView = viewFromPath() || "messages";
  }
}

async function sendFriendRequest(event) {
  event.preventDefault();
  const to = els.friendUserSelect.value;
  if (!to) return;
  try {
    const data = await api("/api/friends/request", { method: "POST", json: { to } });
    state.friends = data.friends;
    renderFriends();
    notify("Friend request sent");
  } catch (error) {
    notify(error.message);
  }
}

async function respondFriendRequest(id, action) {
  try {
    const data = await api("/api/friends/respond", { method: "POST", json: { id, action } });
    state.friends = data.friends;
    renderFriends();
  } catch (error) {
    notify(error.message);
  }
}

async function removeFriend(username) {
  try {
    const data = await api("/api/friends/remove", { method: "POST", json: { username } });
    state.friends = data.friends;
    renderFriends();
  } catch (error) {
    notify(error.message);
  }
}

async function saveProfile(event) {
  event.preventDefault();
  try {
    const data = await api("/api/profile", {
      method: "POST",
      json: {
        displayName: els.profileDisplayName.value,
        avatarUrl: els.profileAvatarUrl.value,
        bannerUrl: els.profileBannerUrl.value,
        badges: els.profileBadges.value.split(",").map((entry) => entry.trim()).filter(Boolean),
        status: els.profileStatus.value,
        customStatus: els.profileCustomStatus.value,
        theme: els.profileTheme.value,
        bio: els.profileBio.value,
        invisible: els.profileInvisible.checked,
      },
    });
    state.profiles = data.profiles || state.profiles;
    renderProfile();
    applyProfileTheme();
    notify("Profile saved");
    sendWs({
      type: "presence:update",
      status: els.profileStatus.value,
      invisible: els.profileInvisible.checked,
      customStatus: els.profileCustomStatus.value,
    });
  } catch (error) {
    notify(error.message);
  }
}

function saveUiState() {
  try {
    localStorage.setItem("innerActiveView", state.activeView || "messages");
    localStorage.setItem("innerSelectedRoom", state.selectedRoomId || "main");
    if (state.selectedDmUser) {
      localStorage.setItem("innerSelectedDm", state.selectedDmUser);
    } else {
      localStorage.removeItem("innerSelectedDm");
    }
  } catch (error) {
    // Local storage can be disabled; navigation still works for this session.
  }
}

function updateRoute(viewName) {
  const nextPath = viewRoutes[viewName] || "/";
  if (window.location.pathname === nextPath) return;
  window.history.pushState({ view: viewName }, "", nextPath);
}

function getStoredFlag(key) {
  try {
    return localStorage.getItem(key) === "on";
  } catch (error) {
    return false;
  }
}

function setStoredFlag(key, value) {
  try {
    if (value) {
      localStorage.setItem(key, "on");
    } else {
      localStorage.removeItem(key);
    }
  } catch (error) {
    // Local storage can be disabled; alerts still work for this session.
  }
}

function downloadUrl(url, filename) {
  const link = document.createElement("a");
  link.href = url;
  link.download = filename || "";
  link.rel = "noopener";
  document.body.append(link);
  link.click();
  link.remove();
}

function downloadText(filename, text, mime = "application/json") {
  const blob = new Blob([text], { type: mime });
  const url = URL.createObjectURL(blob);
  downloadUrl(url, filename);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    notify("Copied");
  } catch (error) {
    window.prompt("Copy this", text);
  }
}

function exportLogs(kind) {
  if (!isOwner()) return notify("Admin access required");
  const exportedAt = new Date().toISOString();
  const filters = {
    search: state.logSearch || "",
    date: state.logDate || "",
  };
  const records = kind === "moderation" ? filteredModerationLogs() : filteredSystemLogs();
  const payload = {
    type: kind === "moderation" ? "moderation logs" : "system logs",
    exportedAt,
    exportedBy: state.user.username,
    filters,
    count: records.length,
    records,
  };
  const day = filters.date || exportedAt.slice(0, 10);
  downloadText(`inner-${kind}-logs-${day}.json`, JSON.stringify(payload, null, 2));
  notify(`${records.length} ${kind} log entries exported`);
}

function formatMoney(priceCents, currency) {
  try {
    return new Intl.NumberFormat([], {
      style: "currency",
      currency: currency || "USD",
    }).format(Number(priceCents || 0) / 100);
  } catch (error) {
    return `${currency || "USD"} ${(Number(priceCents || 0) / 100).toFixed(2)}`;
  }
}

async function api(path, options = {}) {
  const init = {
    method: options.method || "GET",
    credentials: "same-origin",
    headers: options.headers || {},
  };

  if (options.json !== undefined) {
    init.headers = { ...init.headers, "Content-Type": "application/json" };
    init.body = JSON.stringify(options.json);
  }

  let response;
  try {
    response = await fetch(path, init);
  } catch (error) {
    const startupError = new Error(
      "Inner server is still starting or is stopped. Keep this window open for a moment, then try again."
    );
    startupError.network = true;
    throw startupError;
  }
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(data.error || `Request failed (${response.status})`);
    error.status = response.status;
    throw error;
  }
  return data;
}

function isOwner() {
  return state.user && ["owner", "admin", "hmd", "dev"].includes(state.user.role);
}

function isDev() {
  return state.user && ["admin", "hmd", "dev"].includes(state.user.role);
}

function setConnection(value) {
  if (els.connectionStatus) els.connectionStatus.textContent = value;
}

function notify(message) {
  els.toast.textContent = message;
  els.toast.classList.remove("hidden");
  clearTimeout(notify.timer);
  notify.timer = setTimeout(() => els.toast.classList.add("hidden"), 2600);
}

function emptyBlock(message) {
  const block = document.createElement("div");
  block.className = "empty-state-inline";
  block.textContent = message;
  return block;
}

function textNode(value) {
  const span = document.createElement("span");
  span.textContent = value;
  return span;
}

function formatDate(value) {
  if (!value) return "";
  return new Intl.DateTimeFormat([], {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(new Date(value));
}

function formatBytes(bytes) {
  const size = Number(bytes || 0);
  if (size < 1024) return `${size} B`;
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`;
  if (size < 1024 * 1024 * 1024) return `${(size / 1024 / 1024).toFixed(1)} MB`;
  return `${(size / 1024 / 1024 / 1024).toFixed(1)} GB`;
}
